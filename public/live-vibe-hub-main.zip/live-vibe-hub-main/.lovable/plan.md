# AT Live Cafe — Multi-page upgrade

Turn the current single-page landing into a full multi-page site using real At Live Cafe (Hajipur, Noida) data, add a reservation flow, a reviews module, category filters, a per-item menu section, and GSAP-driven interactive dish visuals.

## What we'll build

1. **Real content** — swap placeholder locations/prices for At Live Noida:
   - Address: HA-22, Block A, Sector 104, Hajipur, Noida 201304
   - Phone: 093193 22100 · Hours 12pm–12am · Price ₹600–1,800/pp
   - Ratings: Zomato 4.1 · Swiggy 4.2 · Justdial 4.1 · Google 4.2
   - Menu items (Grilled Fish ₹725, Pizza, Tiramisu ₹395, Sangria, Veg Tacos ₹375, Cappuccino, Rock N Roll Nachos ₹375, Broccoli & Almond Soup ₹375, Indian Raga Lamb Bruschetta ₹475, At Live Sundae ₹325, Chicken Sharabi Tikka, Mocha, etc.)

2. **Routes (multi-page)**
   ```text
   /                       Landing (redesigned pizza-amici style)
   /menu                   Full menu with category tabs
   /menu/$slug             Per-dish page (image, ingredients, allergens, related)
   /events                 All events grid + genre filter
   /events/$eventId        Existing event details page
   /reviews                Full reviews wall + link back to events
   /reserve                Reservation form (name, phone, date, time, party, occasion)
   /reserve/confirmed      Confirmation page with booking summary
   /story                  About / gallery / awards
   /contact                Address, map, hours, phone
   ```

3. **Reservation flow**
   - `/reserve` form: date picker (shadcn calendar), time slots (12pm–11pm in 30-min steps), party size (1–12), occasion, name, phone, email, notes.
   - Zod validation client-side (max lengths, phone regex, future date).
   - On submit → store booking in `localStorage` + navigate to `/reserve/confirmed?ref=AT-XXXX` with a summary card + "Add to calendar" (.ics download) + WhatsApp confirm link to 09319322100.

4. **Reviews module**
   - `/reviews` page: Zomato/Swiggy/Justdial/Google score cards + individual quotes (Joy Banerjee, Mansi Gupta, Md Ashfaque) in polaroid cards.
   - Each review card links to the event it references (e.g. "gazal night" → `/events/rahul-sen-quartet`).
   - Add a compact `<ReviewsStrip />` on the landing.

5. **Category chip filtering (landing)**
   - Chips (Wood-Fired, Brunch, Coffee, Cocktails, Desserts, Live Music) become **stateful** and scope both the menu preview and the events grid on the landing (React `useState`, no route change). Selecting "Live Music" jumps to events, others filter menu.

6. **GSAP interactive marquee + 3D dishes**
   - Install `gsap` + `@gsap/react`.
   - Screenshot/marquee section: horizontal scroll-tied marquee (ScrollTrigger) that speeds up as you scroll.
   - **3D dish plate**: menu highlight card where the plate image responds to pointer (tilt + parallax with GSAP `quickTo`); rotates on hover, shadow follows. Ring text spins around the plate.
   - Section reveals via GSAP `from({y:60, opacity:0, stagger:0.08})` triggered by `ScrollTrigger`.

7. **Layout & shared shell**
   - Move Nav/TopStrip/Footer into `src/components/layout/SiteLayout.tsx` and mount around `<Outlet />` in `__root.tsx` so every new page has the same chrome.
   - Per-route `head()` with unique title, description, og:url, canonical.

## Technical notes

- Data: extend `src/data/events.ts`; add `src/data/menu.ts` (with slug, category, price, description, allergens, image) and `src/data/reviews.ts`.
- Booking storage: `localStorage["atlive.bookings"]` (no backend yet — say so).
- GSAP: dynamic import inside `useEffect` to stay SSR-safe; cleanup via `gsap.context()`.
- 3D: pure CSS `transform-style: preserve-3d` + GSAP pointer parallax. No Three.js unless you want it — it adds a lot of bundle weight for one plate.
- Reservation form: `react-hook-form` + `zod` + shadcn `calendar`/`select`/`input`.
- Keep the existing pizza-amici polaroid/navy/cream/yellow palette everywhere.

## Open question

For the "3D dishes" — is the GSAP tilt/parallax plate above (fast, matches the polaroid aesthetic) enough, or do you want real Three.js WebGL rotating plates? Three.js adds ~150KB and needs 3D models. I'll go with the GSAP version unless you say otherwise.

Approve and I'll build it end-to-end.
