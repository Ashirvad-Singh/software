import { useState, type ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import {
  Menu, X, Ticket, Star, Flame, MapPin, Instagram, Youtube, Phone,
} from "lucide-react";
const logo = { url: "/atlive-logo.png" };

const NAV = [
  { label: "Menu", to: "/menu" as const },
  { label: "Events", to: "/events" as const },
  { label: "Reviews", to: "/reviews" as const },
  { label: "Story", to: "/story" as const },
  { label: "Contact", to: "/contact" as const },
];

function TopStrip() {
  return (
    <div className="bg-foreground text-background text-[11px] sm:text-xs">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 py-2.5 flex items-center justify-center gap-4 sm:gap-8 flex-wrap">
        <span className="flex items-center gap-2"><Flame className="h-3.5 w-3.5" /> Live music · every day · 12pm–12am</span>
        <span className="hidden sm:inline-flex items-center gap-2"><span className="h-1 w-1 rounded-full bg-secondary" /> 4.2 on Google</span>
        <span className="hidden md:inline-flex items-center gap-2">
          {Array.from({ length: 5 }).map((_, i) => (
            <Star key={i} className="h-3 w-3 fill-secondary text-secondary" />
          ))}
        </span>
        <span className="hidden md:inline-flex items-center gap-2"><MapPin className="h-3 w-3" /> HA-22, Sector 104, Noida</span>
      </div>
    </div>
  );
}

export function SiteNav() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-50 bg-background/95 backdrop-blur border-b border-foreground/10">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 py-4 flex items-center justify-between gap-6">
        <Link to="/" className="flex items-center">
          <img
            src={logo.url}
            alt="AT Live Cafe"
            className="h-10 sm:h-12 w-auto"
          />
        </Link>
        <nav className="hidden lg:flex items-center gap-1">
          {NAV.map((n) => (
            <Link
              key={n.label}
              to={n.to}
              className="px-3 py-2 text-sm font-medium hover:text-accent transition-colors"
              activeProps={{ className: "text-accent" }}
            >
              {n.label}
            </Link>
          ))}
        </nav>
        <div className="flex items-center gap-3">
          <a
            href="tel:+919319322100"
            className="hidden md:inline-flex items-center gap-2 text-sm font-medium hover:text-accent"
          >
            <Phone className="h-4 w-4" /> +91 93193 22100
          </a>
          <Link
            to="/reserve"
            className="relative hidden sm:inline-flex items-center gap-2 bg-primary text-primary-foreground font-display text-lg tracking-wide px-6 py-3 shadow-[6px_6px_0_0_var(--color-accent)] hover:translate-x-[2px] hover:translate-y-[2px] hover:shadow-[3px_3px_0_0_var(--color-accent)] transition-all"
            style={{ clipPath: "polygon(8% 0, 100% 0, 92% 100%, 0% 100%)" }}
          >
            <Ticket className="h-4 w-4" /> Reserve
          </Link>
          <button
            className="lg:hidden grid h-10 w-10 place-items-center rounded-full border border-foreground/20"
            onClick={() => setOpen((v) => !v)}
            aria-label="Menu"
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>
      {open && (
        <div className="lg:hidden border-t border-foreground/10 bg-background">
          <div className="mx-auto max-w-7xl px-4 py-3 flex flex-col">
            {NAV.map((n) => (
              <Link
                key={n.label}
                to={n.to}
                onClick={() => setOpen(false)}
                className="py-2.5 border-b border-foreground/5 text-sm font-medium"
              >
                {n.label}
              </Link>
            ))}
            <Link
              to="/reserve"
              onClick={() => setOpen(false)}
              className="mt-3 inline-flex items-center justify-center gap-2 bg-primary text-primary-foreground font-display text-lg px-6 py-3"
            >
              <Ticket className="h-4 w-4" /> Reserve a Table
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer id="contact" className="pt-16 pb-8 bg-background border-t border-foreground/10 mt-16">
      <div className="awning h-4 mb-14" />
      <div className="mx-auto max-w-7xl px-4 sm:px-6 grid gap-10 lg:grid-cols-4">
        <div className="lg:col-span-2">
          <img
            src={logo.url}
            alt="AT Live Cafe"
            className="h-16 w-auto"
          />
          <div className="font-script text-2xl text-accent mt-3">since 2019</div>
          <p className="mt-4 text-sm text-foreground/70 max-w-md">
            A café · music · art space in the heart of Noida. Multi-cuisine kitchen,
            full bar, and live music every single day.
          </p>
          <div className="flex gap-3 mt-6">
            <a href="https://instagram.com/atlivenoida" target="_blank" rel="noreferrer"
               className="h-10 w-10 grid place-items-center border-2 border-foreground rounded-full hover:bg-foreground hover:text-background transition-colors">
              <Instagram className="h-4 w-4" />
            </a>
            <a href="#" className="h-10 w-10 grid place-items-center border-2 border-foreground rounded-full hover:bg-foreground hover:text-background transition-colors">
              <Youtube className="h-4 w-4" />
            </a>
          </div>
        </div>
        <div>
          <div className="text-xs tracking-[0.3em] text-foreground/50">VISIT</div>
          <div className="mt-3 space-y-1 text-sm text-foreground/80">
            <div className="flex gap-2"><MapPin className="h-4 w-4 text-accent mt-0.5"/>
              <span>HA-22, Block A, Sector 104,<br />Hajipur, Noida 201304</span>
            </div>
            <a href="tel:+919319322100" className="flex gap-2 mt-3 hover:text-accent"><Phone className="h-4 w-4 text-accent mt-0.5"/> +91 93193 22100</a>
          </div>
        </div>
        <div>
          <div className="text-xs tracking-[0.3em] text-foreground/50">HOURS</div>
          <div className="mt-3 space-y-1 text-sm text-foreground/80">
            <div>All days · 12 pm – 12 am</div>
            <div className="mt-3 font-script text-lg text-accent">live music, every day</div>
          </div>
        </div>
      </div>
      <div className="mt-12 text-center text-xs text-foreground/50">
        © {new Date().getFullYear()} AT Live Cafe · Sector 104, Noida.
      </div>
    </footer>
  );
}

export default function SiteLayout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      <TopStrip />
      <SiteNav />
      <div className="flex-1">{children}</div>
      <SiteFooter />
    </div>
  );
}