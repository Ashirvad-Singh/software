import { useEffect, useRef, useState } from "react";
import { motion } from "motion/react";
import { Link } from "@tanstack/react-router";
import { ClientOnly } from "@tanstack/react-router";
import {
  ArrowUpRight, Star, MapPin, Clock, ChevronRight,
  Flame, Music, UtensilsCrossed, Coffee, CupSoda, Cake, Ticket,
  ArrowRight, Phone, Sparkles,
  Wifi, ParkingCircle, Wind, Baby, CreditCard, Cigarette, PawPrint,
  Sun, Moon, Sunset, Gift, Users, Cake as CakeIcon, Mic, HeartHandshake,
  Plus, Minus,
} from "lucide-react";

import foodHero from "@/assets/food-hero.jpg";
const heroVideo = { url: "/hero-bg.mp4" };
import food1 from "@/assets/food-1.jpg";
import food2 from "@/assets/food-2.jpg";
import food3 from "@/assets/food-3.jpg";
import cafeInterior from "@/assets/cafe-interior.jpg";
import a1 from "@/assets/artist-1.jpg";
import a2 from "@/assets/artist-2.jpg";
import a3 from "@/assets/artist-3.jpg";
import { EVENTS } from "@/data/events";
import { MENU } from "@/data/menu";
import { REVIEWS, REVIEW_SCORES } from "@/data/reviews";
import FeaturedArtists from "@/components/landing/FeaturedArtists";
import CommunitySection from "@/components/landing/CommunitySection";
import InstagramEmbed from "@/components/landing/InstagramEmbed";



/* ============ Chip filter shared context ============ */
const CHIPS = [
  { key: "all",       label: "ALL",         icon: Sparkles,        color: "bg-background text-foreground border-2 border-foreground" },
  { key: "food",      label: "WOOD FIRED",  icon: Flame,           color: "bg-accent text-accent-foreground" },
  { key: "brunch",    label: "SMALL PLATES",icon: UtensilsCrossed, color: "bg-secondary text-foreground" },
  { key: "coffee",    label: "COFFEE",      icon: Coffee,          color: "bg-background text-foreground border-2 border-foreground" },
  { key: "cocktails", label: "COCKTAILS",   icon: CupSoda,         color: "bg-foreground text-background" },
  { key: "desserts",  label: "DESSERTS",    icon: Cake,            color: "bg-secondary text-foreground" },
  { key: "live",      label: "LIVE MUSIC",  icon: Music,           color: "bg-accent text-accent-foreground" },
] as const;

type ChipKey = typeof CHIPS[number]["key"];

function chipMatchesMenu(key: ChipKey, category: string): boolean {
  if (key === "all") return true;
  if (key === "food") return category === "Signatures" || category === "Mains" || category === "Pizza";
  if (key === "brunch") return category === "Small Plates";
  if (key === "coffee") return category === "Coffee";
  if (key === "cocktails") return category === "Cocktails";
  if (key === "desserts") return category === "Desserts";
  return true;
}

/* ============ HERO ============ */
function Hero() {
  return (
    <section className="relative overflow-hidden">
      <div className="awning h-6 sm:h-8" />
      <div className="relative">
        <video
          src={heroVideo.url}
          autoPlay
          muted
          loop
          playsInline
          poster={cafeInterior}
          aria-label="AT Live Cafe kitchen — Sector 104, Noida"
          className="w-full h-[62vh] sm:h-[78vh] object-cover"
        />
        <div className="absolute inset-0 bg-foreground/40" />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-background" />

        <div className="absolute inset-0 flex items-center justify-center px-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8 }}
            className="relative bg-background/95 backdrop-blur-sm border-[3px] border-foreground text-foreground px-8 sm:px-16 py-10 sm:py-14 text-center max-w-3xl"
            style={{ clipPath: "polygon(10% 0, 90% 0, 100% 50%, 90% 100%, 10% 100%, 0 50%)" }}
          >
            <div className="flex items-center justify-center gap-3 text-xs tracking-[0.35em] text-foreground/70">
              <span>GOOGLE</span>
              <span className="flex gap-0.5">
                {Array.from({length:5}).map((_,i)=>(<Star key={i} className="h-3 w-3 fill-foreground text-foreground"/>))}
              </span>
              <span>4.2 · 725 REVIEWS</span>
            </div>
            <h1 className="mt-4 font-display leading-[0.9] text-[clamp(2.4rem,7vw,5.5rem)] uppercase">
              Café · Music · Art<br />
              <span className="text-accent">In one room.</span>
            </h1>
            <div className="mt-4 text-xs sm:text-sm tracking-[0.25em] text-foreground/70">
              MULTI&nbsp;CUISINE · FULL&nbsp;BAR · LIVE&nbsp;EVERY&nbsp;DAY
            </div>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 40, rotate: -8 }}
          animate={{ opacity: 1, y: 0, rotate: -6 }}
          transition={{ delay: 0.3, duration: 0.7 }}
          className="hidden lg:block absolute left-4 xl:left-10 bottom-10 w-44 xl:w-52 polaroid z-10"
          style={{ ["--tilt" as any]: "-6deg" }}
        >
          <img src={food1} alt="Grilled Fish" className="w-full h-44 xl:h-52 object-cover" />
          <div className="absolute bottom-2 left-0 right-0 text-center font-script text-lg">
            grilled fish
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 40, rotate: 8 }}
          animate={{ opacity: 1, y: 0, rotate: 5 }}
          transition={{ delay: 0.45, duration: 0.7 }}
          className="hidden lg:block absolute right-4 xl:right-10 top-20 w-40 xl:w-48 polaroid z-10"
          style={{ ["--tilt" as any]: "5deg" }}
        >
          <img src={food2} alt="House Sangria" className="w-full h-40 xl:h-48 object-cover" />
          <div className="absolute bottom-2 left-0 right-0 text-center font-script text-lg">
            house sangria
          </div>
        </motion.div>

        <div className="hidden xl:block absolute left-72 bottom-20 font-script text-2xl text-background rotate-[-6deg] max-w-[220px] drop-shadow-lg">
          The friendliest cafe · music · art in Noida!
        </div>
      </div>

      <div className="bg-background">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 py-6 flex flex-wrap items-center justify-between gap-4 text-sm">
          <span className="flex items-center gap-2"><span className="text-2xl font-display">35k+</span> Instagram fam</span>
          <span className="hidden sm:block h-1 w-1 rounded-full bg-foreground/40" />
          <span className="flex items-center gap-2"><span className="text-2xl font-display">1,400+</span> live shows</span>
          <span className="hidden sm:block h-1 w-1 rounded-full bg-foreground/40" />
          <span className="flex items-center gap-2"><span className="text-2xl font-display">4.2/5</span> Google · 725 reviews</span>
          <span className="hidden sm:block h-1 w-1 rounded-full bg-foreground/40" />
          <span className="flex items-center gap-2"><span className="text-2xl font-display">₹600–1,800</span> per person</span>
        </div>
      </div>
    </section>
  );
}

/* ============ GSAP marquee ============ */
function GsapMarquee() {
  const trackRef = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    let ctx: any;
    (async () => {
      const gsapMod = await import("gsap");
      const st = await import("gsap/ScrollTrigger");
      const gsap = gsapMod.default || gsapMod.gsap;
      gsap.registerPlugin(st.ScrollTrigger);
      if (!trackRef.current) return;
      ctx = gsap.context(() => {
        gsap.to(trackRef.current, {
          xPercent: -50,
          ease: "none",
          duration: 30,
          repeat: -1,
        });
        gsap.to(trackRef.current, {
          timeScale: 2.5,
          scrollTrigger: {
            trigger: trackRef.current!.parentElement!,
            start: "top bottom",
            end: "bottom top",
            scrub: 0.5,
          },
        });
      }, trackRef);
    })();
    return () => ctx?.revert?.();
  }, []);

  const words = [
    "PIZZA", "GAZAL", "COFFEE", "SUFI", "TIRAMISU", "OPEN MIC",
    "SANGRIA", "BOLLYWOOD", "TIKKA", "ACOUSTIC", "TACOS", "LATE NIGHTS",
  ];
  return (
    <section className="bg-foreground text-secondary py-6 overflow-hidden border-y-4 border-secondary">
      <div ref={trackRef} className="flex gap-10 whitespace-nowrap font-display text-4xl sm:text-6xl uppercase tracking-tight will-change-transform">
        {[...words, ...words].map((w, i) => (
          <span key={i} className="flex items-center gap-10">
            {w}
            <span className="h-3 w-3 rounded-full bg-accent inline-block" />
          </span>
        ))}
      </div>
    </section>
  );
}

/* ============ Chip row (stateful) ============ */
function ChipRow({ active, onChange }: { active: ChipKey; onChange: (k: ChipKey) => void }) {
  return (
    <section className="py-4 sm:py-8 border-b border-foreground/10 sticky top-[57px] z-30 bg-background/95 backdrop-blur">
      <div className="mx-auto max-w-7xl px-3 sm:px-6 flex flex-wrap items-center justify-center gap-2 sm:gap-3">
        {CHIPS.map(({ key, label, icon: Icon, color }, i) => {
          const on = active === key;
          return (
            <motion.button
              key={key}
              onClick={() => {
                onChange(key);
                if (key === "live") {
                  document.getElementById("events")?.scrollIntoView({ behavior: "smooth" });
                } else if (key !== "all") {
                  document.getElementById("menu")?.scrollIntoView({ behavior: "smooth" });
                }
              }}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.04 }}
              className={`inline-flex items-center gap-1.5 sm:gap-2 px-3 py-1.5 sm:px-5 sm:py-2.5 rounded-full font-display tracking-wider text-xs sm:text-sm transition-all ${
                on
                  ? "bg-foreground text-background scale-105 shadow-[3px_3px_0_0_var(--color-accent)] sm:shadow-[4px_4px_0_0_var(--color-accent)]"
                  : color
              } hover:-translate-y-0.5`}
            >
              <Icon className="h-3 w-3 sm:h-4 sm:w-4" /> {label}
            </motion.button>
          );
        })}
      </div>
    </section>
  );
}

/* ============ Featured dish showcase (fills left column) ============ */
function DishPlate3D({ dish }: { dish: { name: string; price: string; img: string; short: string; slug: string; chefPick?: boolean } }) {
  const wrap = useRef<HTMLDivElement | null>(null);
  const inner = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    let ctx: any;
    let cleanup: (() => void) | null = null;
    (async () => {
      const g = await import("gsap");
      const gsap = g.default || g.gsap;
      if (!wrap.current || !inner.current) return;
      const setX = gsap.quickTo(inner.current, "rotationY", { duration: 0.6, ease: "power3" });
      const setY = gsap.quickTo(inner.current, "rotationX", { duration: 0.6, ease: "power3" });
      const el = wrap.current;
      const onMove = (e: PointerEvent) => {
        const r = el.getBoundingClientRect();
        const x = (e.clientX - r.left) / r.width - 0.5;
        const y = (e.clientY - r.top) / r.height - 0.5;
        setX(x * 14);
        setY(-y * 14);
      };
      const onLeave = () => { setX(0); setY(0); };
      el.addEventListener("pointermove", onMove);
      el.addEventListener("pointerleave", onLeave);
      ctx = gsap.context(() => {
        gsap.set(inner.current, { transformPerspective: 900 });
      }, wrap);
      cleanup = () => {
        el.removeEventListener("pointermove", onMove);
        el.removeEventListener("pointerleave", onLeave);
      };
    })();
    return () => { ctx?.revert?.(); cleanup?.(); };
  }, []);

  return (
    <div ref={wrap} className="relative w-full max-w-xl mx-auto lg:mx-0" style={{ perspective: 1000 }}>
      {/* Background decorative scribble */}
      <div className="absolute -top-8 -left-8 w-40 h-40 rounded-full bg-accent/10 blur-3xl" />
      <div className="absolute -bottom-10 right-0 w-48 h-48 rounded-full bg-secondary/40 blur-3xl" />

      <motion.div
        ref={inner}
        initial={{ opacity: 0, rotateY: -8, rotateX: 4 }}
        whileInView={{ opacity: 1, rotateY: -3, rotateX: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="relative paper p-3 sm:p-4 rotate-[-1deg] shadow-[0_40px_80px_-20px_rgba(0,0,0,0.25)]"
        style={{ transformStyle: "preserve-3d" }}
      >
        {/* Main dish image */}
        <div className="relative aspect-[4/3] overflow-hidden border-2 border-foreground/10">
          <img src={dish.img} alt={dish.name} className="h-full w-full object-cover" />
          {dish.chefPick && (
            <div className="absolute top-3 left-3 bg-accent text-background text-[10px] font-display tracking-widest px-2 py-1">
              CHEF PICK
            </div>
          )}
        </div>

        {/* Info card inside paper */}
        <div className="mt-4 px-2 pb-2">
          <div className="flex items-start justify-between gap-4">
            <div className="min-w-0">
              <h3 className="font-display text-2xl sm:text-3xl uppercase leading-none truncate">{dish.name}</h3>
              <p className="mt-2 text-sm text-foreground/70 max-w-[260px]">{dish.short}</p>
            </div>
          </div>

          <div className="mt-5 flex items-center justify-between">
            <div className="flex items-center gap-1 text-xs text-foreground/60">
              <Star className="h-3.5 w-3.5 fill-foreground text-foreground" />
              <span className="font-display">4.8</span>
              <span>· most ordered</span>
            </div>
            <Link
              to="/menu/$slug"
              params={{ slug: dish.slug }}
              className="inline-flex items-center gap-1.5 text-xs font-display tracking-widest bg-foreground text-background px-4 py-2 hover:bg-accent hover:text-background transition-colors"
            >
              SEE DISH <ArrowUpRight className="h-3.5 w-3.5" />
            </Link>
          </div>
        </div>

        {/* Tape detail */}
        <div className="absolute -top-3 left-1/2 -translate-x-1/2 w-24 h-6 bg-foreground/10 rotate-1" />
      </motion.div>

      {/* Handwritten badge - top right, clear of content */}
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        transition={{ delay: 0.5, duration: 0.5 }}
        className="absolute -right-3 -top-4 bg-accent text-background rounded-full h-16 w-16 sm:h-20 sm:w-20 flex items-center justify-center font-script text-base sm:text-lg leading-tight text-center rotate-12 shadow-lg z-20"
      >
        made<br />fresh
      </motion.div>
    </div>
  );
}

/* ============ Menu Preview (filtered) ============ */
function MenuPreview({ active }: { active: ChipKey }) {
  const filtered = MENU.filter((m) => chipMatchesMenu(active, m.category)).slice(0, 6);
  const hero = MENU.find((m) => m.slug === "wood-fired-pizza") || MENU[0];
  return (
    <section id="menu" className="py-20 sm:py-28 relative">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 grid lg:grid-cols-2 gap-16 items-center">
        <ClientOnly fallback={<div className="aspect-square w-full rounded-full bg-muted/30" />}>
          <DishPlate3D dish={hero} />
        </ClientOnly>

        <div>
          <div className="text-xs tracking-[0.35em] text-accent">FROM THE KITCHEN</div>
          <h2 className="mt-3 font-display text-5xl sm:text-6xl uppercase leading-[0.95]">
            Multi-cuisine.<br />Made from scratch.
          </h2>
          <p className="mt-4 text-foreground/70 max-w-md">
            Chinese, pizza, Italian, Continental, North Indian, biryani, desserts, shakes.
            Everything on one menu — nothing on the shortcut list.
          </p>

          <div className="mt-8 grid sm:grid-cols-2 gap-3">
            {filtered.map((m) => (
              <Link
                key={m.slug}
                to="/menu/$slug"
                params={{ slug: m.slug }}
                className="group flex gap-3 p-3 border-2 border-foreground/10 rounded-xl hover:border-accent hover:bg-card transition-colors"
              >
                <img src={m.img} alt={m.name} className="h-16 w-16 rounded-lg object-cover" />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-display text-sm uppercase truncate">{m.name}</span>
                    {m.chefPick && <span className="text-[9px] tracking-widest text-accent">CHEF</span>}
                  </div>
                  <div className="text-[11px] text-foreground/60 truncate">{m.short}</div>
                </div>
              </Link>
            ))}
          </div>

          <div className="mt-8">
            <Link
              to="/menu"
              className="inline-flex items-center gap-2 bg-foreground text-background font-display text-lg tracking-wide px-8 py-4"
            >
              SEE FULL MENU <ArrowUpRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ============ Events section (filtered) ============ */
function EventsSection({ active }: { active: ChipKey }) {
  const shown = active === "live"
    ? EVENTS
    : EVENTS.filter((e) => e.featured);
  return (
    <section id="events" className="relative bg-foreground text-background py-20 sm:py-28 overflow-hidden">
      <div className="absolute right-8 top-10 font-script text-3xl text-secondary rotate-[-6deg] hidden sm:block">
        live music · every day
      </div>

      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="max-w-2xl">
          <div className="text-xs tracking-[0.35em] text-secondary">EVENTS AT THE CAFE</div>
          <h2 className="mt-3 font-display text-5xl sm:text-6xl leading-[0.95] uppercase">
            Book a table.<br />Stay for the show.
          </h2>
          <p className="mt-4 text-background/70 max-w-lg">
            Gazal, Sufi, Bollywood, acoustic and open mic. Same kitchen, same bar,
            unforgettable set on the side. Zero cover on most nights.
          </p>
        </div>

        <div className="mt-14 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {shown.slice(0, 6).map((e, i) => {
            const tilts = ["-3deg", "2deg", "-2deg", "3deg", "-1deg", "1deg"];
            return (
              <motion.div
                key={e.slug}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ delay: (i % 3) * 0.1, duration: 0.6 }}
                style={{ ["--tilt" as any]: tilts[i % tilts.length] }}
                className="polaroid group"
              >
                <Link to="/events/$eventId" params={{ eventId: e.slug }} className="block">
                  <div className="relative overflow-hidden">
                    <img src={e.img} alt={e.artist} className="w-full h-64 object-cover" />
                    <span className="absolute top-3 left-3 bg-secondary text-foreground text-[10px] tracking-[0.25em] px-2 py-1 font-display">
                      {e.genre.toUpperCase()}
                    </span>
                    <span className="absolute top-3 right-3 bg-background text-foreground text-[10px] tracking-[0.2em] px-2 py-1">
                      {e.seats} SEATS
                    </span>
                  </div>
                  <div className="mt-3 px-1">
                    <div className="font-display text-xl leading-tight text-foreground uppercase">{e.artist}</div>
                    <div className="mt-1 flex items-center justify-between text-xs text-foreground/70">
                      <span className="flex items-center gap-1"><Clock className="h-3 w-3" />{e.date} · {e.time}</span>
                      <span className="font-display text-sm text-accent">FREE ENTRY</span>
                    </div>
                  </div>
                  <div className="absolute bottom-2 left-0 right-0 text-center font-script text-lg text-foreground/80">
                    live · sector 104
                  </div>
                </Link>
              </motion.div>
            );
          })}
        </div>

        <div className="mt-14 flex justify-center gap-3 flex-wrap">
          <Link to="/events" className="inline-flex items-center gap-2 bg-secondary text-foreground font-display text-lg tracking-wide px-8 py-4 shadow-[6px_6px_0_0_#f4ead5] hover:translate-x-[2px] hover:translate-y-[2px] hover:shadow-[3px_3px_0_0_#f4ead5] transition-all"
             style={{ clipPath: "polygon(6% 0, 100% 0, 94% 100%, 0 100%)" }}>
            SEE THE FULL CALENDAR <ArrowRight className="h-4 w-4" />
          </Link>
          <Link to="/reserve" className="inline-flex items-center gap-2 border-2 border-background/40 text-background font-display text-lg px-8 py-4">
            <Ticket className="h-4 w-4" /> RESERVE
          </Link>
        </div>
      </div>
    </section>
  );
}

/* ============ Ciao letter ============ */
function Ciao() {
  return (
    <section id="story" className="py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 grid lg:grid-cols-2 gap-10 items-center">
        <motion.div
          initial={{ opacity: 0, y: 30, rotate: -1 }}
          whileInView={{ opacity: 1, y: 0, rotate: -1 }}
          viewport={{ once: true }}
          className="relative paper p-8 sm:p-12"
        >
          <span className="absolute -top-3 left-8 w-24 h-6 bg-secondary/70 rotate-[-4deg] shadow-sm" />
          <span className="absolute -top-3 right-10 w-16 h-6 bg-accent/40 rotate-[6deg] shadow-sm" />

          <h2 className="font-script text-6xl sm:text-7xl text-foreground">Namaste!</h2>
          <p className="mt-4 text-foreground/80 leading-relaxed">
            We're <b>AT Live</b> — Noida's café · music · art space. A neighbourhood
            kitchen that runs from noon till midnight, with a full multi-cuisine menu,
            a proper bar, and a small stage that lights up every single evening.
          </p>
          <p className="mt-4 text-foreground/80 leading-relaxed">
            The events are a love letter to our guests — gazal, sufi, acoustic,
            Bollywood, open mic. But make no mistake: <i>the cafe is the star.</i>
          </p>
          <div className="mt-6 font-script text-3xl text-accent">— Team AT Live · Sector 104</div>
        </motion.div>

        <div className="relative h-[520px]">
          <motion.div
            initial={{ opacity: 0, y: 30, rotate: -4 }} whileInView={{ opacity: 1, y: 0, rotate: -4 }} viewport={{ once: true }}
            className="absolute left-0 top-4 w-64 polaroid" style={{ ["--tilt" as any]: "-4deg" }}
          >
            <img src={food3} alt="Chef plate" className="w-full h-72 object-cover" />
            <div className="absolute bottom-3 left-0 right-0 text-center font-script text-xl">from the kitchen</div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 30, rotate: 6 }} whileInView={{ opacity: 1, y: 0, rotate: 6 }} viewport={{ once: true }}
            className="absolute right-4 top-24 w-60 polaroid" style={{ ["--tilt" as any]: "6deg" }}
          >
            <img src={cafeInterior} alt="Room" className="w-full h-64 object-cover" />
            <div className="absolute bottom-3 left-0 right-0 text-center font-script text-xl">our little room</div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }}
            className="absolute right-10 bottom-4 h-40 w-40 rounded-full bg-foreground text-background grid place-items-center text-center p-4"
            style={{ animation: "spin-slow 30s linear infinite" }}
          >
            <div>
              <div className="font-display text-3xl leading-none">35k+</div>
              <div className="text-[10px] tracking-[0.25em] mt-1">INSTAGRAM FAM</div>
            </div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }}
            className="absolute left-24 bottom-16 h-32 w-32 rounded-full bg-secondary text-foreground grid place-items-center text-center p-3 shadow-[var(--shadow-polaroid)]"
          >
            <div>
              <div className="font-display text-2xl leading-none">4.2★</div>
              <div className="text-[9px] tracking-[0.25em] mt-1">GOOGLE · 725</div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

/* ============ Reviews Strip ============ */
function ReviewsStrip() {
  return (
    <section className="py-16 sm:py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="flex items-end justify-between flex-wrap gap-4">
          <div>
            <div className="text-xs tracking-[0.35em] text-accent">SAID ABOUT US</div>
            <h2 className="mt-3 font-display text-4xl sm:text-5xl uppercase leading-[0.95]">
              Reviews from the room.
            </h2>
          </div>
          <Link to="/reviews" className="inline-flex items-center gap-1 text-sm font-medium hover:text-accent">
            All reviews <ChevronRight className="h-4 w-4" />
          </Link>
        </div>

        <div className="mt-6 flex flex-wrap items-center gap-3">
          {REVIEW_SCORES.map((s) => (
            <div key={s.source} className="inline-flex items-center gap-2 border-2 border-foreground rounded-full px-4 py-2">
              <span className="font-display text-lg">{s.score}</span>
              <Star className="h-3 w-3 fill-accent text-accent" />
              <span className="text-xs tracking-widest">{s.source.toUpperCase()} · {s.count}</span>
            </div>
          ))}
        </div>

        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {REVIEWS.slice(0, 3).map((r, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.06 }}
              className="paper p-5 rotate-[-1deg] hover:rotate-0 transition-transform"
            >
              <div className="flex gap-0.5 mb-2">
                {Array.from({length:5}).map((_,k)=>(
                  <Star key={k} className={`h-3 w-3 ${k < r.rating ? "fill-accent text-accent" : "text-foreground/30"}`}/>
                ))}
              </div>
              <p className="text-sm text-foreground/80 leading-relaxed">&ldquo;{r.quote}&rdquo;</p>
              <div className="mt-3 flex items-center justify-between">
                <div className="font-script text-lg text-foreground/70">— {r.who}</div>
                {r.linkTo && r.linkLabel && (
                  <Link
                    to="/events/$eventId"
                    params={{ eventId: r.linkTo }}
                    className="text-[10px] font-display tracking-widest text-accent hover:underline inline-flex items-center gap-1"
                  >
                    {r.linkLabel} <ArrowUpRight className="h-3 w-3" />
                  </Link>
                )}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ============ Awards ribbons ============ */
function Awards() {
  return (
    <section className="py-10 space-y-3">
      <div className="bg-background border-y-2 border-foreground py-4 overflow-hidden">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 flex items-center justify-center gap-4 text-center flex-wrap">
          <span className="font-display text-2xl sm:text-3xl">4.2 SCORE</span>
          <span className="flex">{Array.from({length:5}).map((_,i)=><Star key={i} className="h-4 w-4 fill-accent text-accent"/>)}</span>
          <span className="font-display text-2xl sm:text-3xl">ON GOOGLE · 725 REVIEWS</span>
        </div>
      </div>
      <div className="bg-secondary text-foreground py-3 -rotate-1">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 text-center font-display text-xl sm:text-2xl tracking-wide">
          BEST EVERYDAY LIVE MUSIC IN NCR · INSTAGRAM · 35K FAM
        </div>
      </div>
      <div className="bg-accent text-accent-foreground py-3 rotate-1">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 text-center font-display text-xl sm:text-2xl tracking-wide">
          #1 CAFÉ · MUSIC · ART · SECTOR 104 NOIDA
        </div>
      </div>
    </section>
  );
}

/* ============ Reserve strip ============ */
function ReserveStrip() {
  return (
    <section id="reserve" className="bg-foreground text-background py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 grid lg:grid-cols-2 gap-12 items-center">
        <div>
          <div className="text-xs tracking-[0.35em] text-secondary">RESERVE</div>
          <h2 className="mt-3 font-display text-5xl sm:text-6xl uppercase leading-[0.95]">
            Save a table.<br />We'll save you a story.
          </h2>
          <p className="mt-4 text-background/70 max-w-lg">
            Lunch, dinner or a live night — pick your slot and party size, we take care
            of the rest. Groups &amp; private events: call us.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link to="/reserve" className="inline-flex items-center gap-2 bg-secondary text-foreground font-display text-lg px-8 py-4 shadow-[6px_6px_0_0_var(--color-accent)]">
              BOOK A TABLE <ArrowUpRight className="h-4 w-4" />
            </Link>
            <a href="tel:+919319322100" className="inline-flex items-center gap-2 border-2 border-background/40 text-background font-display text-lg px-8 py-4">
              <Phone className="h-4 w-4" /> +91 93193 22100
            </a>
          </div>
        </div>
        <div className="relative h-[380px]">
          <motion.div initial={{ opacity: 0, rotate: -10 }} whileInView={{ opacity: 1, rotate: -6 }} viewport={{ once: true }} className="absolute left-0 top-0 w-56 polaroid" style={{ ["--tilt" as any]: "-6deg" }}>
            <img src={a1} alt="Artist" className="w-full h-56 object-cover" />
            <div className="absolute bottom-2 left-0 right-0 text-center font-script text-lg text-foreground">friday · gazal</div>
          </motion.div>
          <motion.div initial={{ opacity: 0, rotate: 10 }} whileInView={{ opacity: 1, rotate: 6 }} viewport={{ once: true }} className="absolute right-0 top-16 w-52 polaroid" style={{ ["--tilt" as any]: "6deg" }}>
            <img src={a2} alt="Artist" className="w-full h-52 object-cover" />
            <div className="absolute bottom-2 left-0 right-0 text-center font-script text-lg text-foreground">saturday · sufi</div>
          </motion.div>
          <motion.div initial={{ opacity: 0, rotate: -4 }} whileInView={{ opacity: 1, rotate: -2 }} viewport={{ once: true }} className="absolute left-16 bottom-0 w-56 polaroid" style={{ ["--tilt" as any]: "-2deg" }}>
            <img src={a3} alt="Artist" className="w-full h-48 object-cover" />
            <div className="absolute bottom-2 left-0 right-0 text-center font-script text-lg text-foreground">sunday · acoustic</div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

export default function Landing() {
  return _default();
}

/* ============ Signature Carousel (marquee of chef picks) ============ */
/* ============ Interactive 3D Showcase (parallax + tilt + orbit) ============ */
function Interactive3DShowcase() {
  const stage = useRef<HTMLDivElement | null>(null);
  const vinyl = useRef<HTMLDivElement | null>(null);
  const cup = useRef<HTMLDivElement | null>(null);
  const slice = useRef<HTMLDivElement | null>(null);
  const orb = useRef<HTMLDivElement | null>(null);
  const glow = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    let ctx: any;
    let cleanup: (() => void) | null = null;
    (async () => {
      const g = await import("gsap");
      const gsap = g.default || g.gsap;
      if (!stage.current) return;

      const isCoarse = window.matchMedia("(pointer: coarse)").matches;
      const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

      // continuous spins
      ctx = gsap.context(() => {
        gsap.set([vinyl.current, cup.current, slice.current, orb.current], {
          transformPerspective: 1000,
          transformStyle: "preserve-3d",
        });
        if (!reduced) {
          gsap.to(vinyl.current, { rotation: 360, duration: isCoarse ? 20 : 14, ease: "none", repeat: -1 });
          gsap.to(orb.current, { rotationY: 360, duration: 18, ease: "none", repeat: -1 });
          gsap.to(slice.current, {
            y: -18, rotation: 6, duration: 2.4,
            yoyo: true, repeat: -1, ease: "sine.inOut",
          });
          gsap.to(cup.current, {
            y: -12, duration: 3,
            yoyo: true, repeat: -1, ease: "sine.inOut",
          });
        }
      }, stage);

      // parallax setters (smooth ease). On coarse pointer (mobile), we use a
      // gentle passive tilt driven by scroll instead of pointer to save perf.
      const els = [
        { el: vinyl.current, depth: 30 },
        { el: cup.current, depth: 55 },
        { el: slice.current, depth: 70 },
        { el: orb.current, depth: 20 },
        { el: glow.current, depth: 15 },
      ];
      const setters = els.map(({ el, depth }) => ({
        el,
        x: gsap.quickTo(el, "x", { duration: 0.9, ease: "power3" }),
        y: gsap.quickTo(el, "y", { duration: 0.9, ease: "power3" }),
        rx: gsap.quickTo(el, "rotationX", { duration: 0.9, ease: "power3" }),
        ry: gsap.quickTo(el, "rotationY", { duration: 0.9, ease: "power3" }),
        depth,
      }));

      // Smooth hover kick on individual hero props
      const hoverTargets = [
        { el: cup.current, s: 1.08, r: -6 },
        { el: slice.current, s: 1.1, r: 8 },
        { el: vinyl.current, s: 1.03, r: 0 },
      ];
      const hoverHandlers: Array<() => void> = [];
      hoverTargets.forEach(({ el, s, r }) => {
        if (!el) return;
        const enter = () => gsap.to(el, { scale: s, rotate: `+=${r}`, duration: 0.5, ease: "power3.out", overwrite: "auto" });
        const leave = () => gsap.to(el, { scale: 1, duration: 0.7, ease: "elastic.out(1, 0.5)", overwrite: "auto" });
        el.addEventListener("pointerenter", enter);
        el.addEventListener("pointerleave", leave);
        hoverHandlers.push(() => {
          el.removeEventListener("pointerenter", enter);
          el.removeEventListener("pointerleave", leave);
        });
      });

      // Click-to-animate: vinyl spin burst + shockwave ripple + prop bounce
      const onClick = (e: PointerEvent) => {
        const r = stage.current!.getBoundingClientRect();
        const px = e.clientX - r.left;
        const py = e.clientY - r.top;

        // vinyl fast spin kick
        if (vinyl.current) {
          gsap.to(vinyl.current, { rotation: "+=720", duration: 1.6, ease: "power4.out" });
        }
        gsap.fromTo(
          [cup.current, slice.current].filter(Boolean),
          { scale: 1 },
          { scale: 1.15, duration: 0.25, yoyo: true, repeat: 1, ease: "power2.out" }
        );
        gsap.fromTo(
          glow.current,
          { scale: 0.9, opacity: 1 },
          { scale: 1.25, opacity: 0.6, duration: 0.9, ease: "power2.out" }
        );

        // ripple element
        const ripple = document.createElement("span");
        ripple.style.cssText = `position:absolute;left:${px}px;top:${py}px;width:20px;height:20px;border-radius:9999px;border:2px solid color-mix(in oklab, var(--color-accent) 80%, transparent);transform:translate(-50%,-50%);pointer-events:none;`;
        stage.current!.appendChild(ripple);
        gsap.to(ripple, {
          width: 320, height: 320, opacity: 0, duration: 1, ease: "power3.out",
          onComplete: () => ripple.remove(),
        });

        // spark burst
        const burst = 10;
        for (let i = 0; i < burst; i++) {
          const s = document.createElement("span");
          s.style.cssText = `position:absolute;left:${px}px;top:${py}px;width:6px;height:6px;border-radius:9999px;background:var(--color-accent);pointer-events:none;`;
          stage.current!.appendChild(s);
          const a = (Math.PI * 2 * i) / burst + Math.random() * 0.4;
          const d = 80 + Math.random() * 60;
          gsap.to(s, {
            x: Math.cos(a) * d, y: Math.sin(a) * d,
            opacity: 0, scale: 0.2, duration: 0.9, ease: "power3.out",
            onComplete: () => s.remove(),
          });
        }
      };

      const onMove = (e: PointerEvent) => {
        const r = stage.current!.getBoundingClientRect();
        const x = (e.clientX - r.left) / r.width - 0.5;
        const y = (e.clientY - r.top) / r.height - 0.5;
        setters.forEach((s) => {
          s.x(x * s.depth);
          s.y(y * s.depth);
          s.rx(-y * 20);
          s.ry(x * 20);
        });
      };
      const onLeave = () => {
        setters.forEach((s) => { s.x(0); s.y(0); s.rx(0); s.ry(0); });
      };

      // Mobile: subtle scroll-driven parallax (no pointer tracking)
      let onScroll: (() => void) | null = null;
      if (!isCoarse && !reduced) {
        stage.current.addEventListener("pointermove", onMove);
        stage.current.addEventListener("pointerleave", onLeave);
      } else if (!reduced) {
        onScroll = () => {
          const r = stage.current!.getBoundingClientRect();
          const vh = window.innerHeight || 1;
          const t = Math.max(-0.5, Math.min(0.5, 0.5 - (r.top + r.height / 2) / vh));
          setters.forEach((s) => { s.y(t * s.depth); s.rx(-t * 10); });
        };
        window.addEventListener("scroll", onScroll, { passive: true });
        onScroll();
      }

      stage.current.addEventListener("pointerdown", onClick);

      cleanup = () => {
        stage.current?.removeEventListener("pointermove", onMove);
        stage.current?.removeEventListener("pointerleave", onLeave);
        stage.current?.removeEventListener("pointerdown", onClick);
        if (onScroll) window.removeEventListener("scroll", onScroll);
        hoverHandlers.forEach((fn) => fn());
      };
    })();
    return () => { ctx?.revert?.(); cleanup?.(); };
  }, []);

  return (
    <section className="relative py-24 sm:py-32 bg-foreground text-background overflow-hidden">
      {/* grid backdrop */}
      <div
        className="absolute inset-0 opacity-[0.08] pointer-events-none"
        style={{
          backgroundImage:
            "linear-gradient(currentColor 1px, transparent 1px), linear-gradient(90deg, currentColor 1px, transparent 1px)",
          backgroundSize: "40px 40px",
        }}
      />
      <div className="mx-auto max-w-7xl px-4 sm:px-6 grid lg:grid-cols-2 gap-12 items-center relative">
        <div>
          <div className="text-xs tracking-[0.35em] text-secondary">INTERACTIVE · MOVE · HOVER · TAP</div>
          <h2 className="mt-3 font-display text-5xl sm:text-6xl uppercase leading-[0.95]">
            Spin the room.<br />
            <span className="text-accent">Hear the vibe.</span>
          </h2>
          <p className="mt-5 text-background/70 max-w-md">
            Wood-fired pizza, hot espresso and a vinyl on the corner stage.
            Move your cursor, hover the props, tap anywhere on the plate — feel it in 3D.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link to="/menu" className="inline-flex items-center gap-2 bg-secondary text-foreground font-display px-6 py-3">
              TASTE IT <ArrowUpRight className="h-4 w-4" />
            </Link>
            <Link to="/events" className="inline-flex items-center gap-2 border-2 border-background/40 font-display px-6 py-3">
              <Music className="h-4 w-4" /> TONIGHT'S SET
            </Link>
          </div>
        </div>

        {/* 3D stage */}
        <div
          ref={stage}
          className="relative aspect-square max-w-lg mx-auto w-full cursor-pointer select-none touch-manipulation"
          style={{ perspective: 1200 }}
        >
          {/* soft glow */}
          <div
            ref={glow}
            className="absolute inset-8 rounded-full pointer-events-none"
            style={{
              background:
                "radial-gradient(circle at 50% 50%, color-mix(in oklab, var(--color-accent) 60%, transparent), transparent 65%)",
              filter: "blur(30px)",
            }}
          />

          {/* wireframe orb (back layer) */}
          <div
            ref={orb}
            className="absolute inset-6 rounded-full border-2 border-background/20"
            style={{
              boxShadow: "inset 0 0 60px rgba(255,255,255,0.05)",
              background:
                "conic-gradient(from 0deg, transparent 0 30deg, rgba(255,255,255,0.06) 30deg 60deg, transparent 60deg 90deg, rgba(255,255,255,0.06) 90deg 120deg, transparent 120deg 150deg, rgba(255,255,255,0.06) 150deg 180deg, transparent 180deg 210deg, rgba(255,255,255,0.06) 210deg 240deg, transparent 240deg 270deg, rgba(255,255,255,0.06) 270deg 300deg, transparent 300deg 330deg, rgba(255,255,255,0.06) 330deg 360deg)",
            }}
          />

          {/* vinyl record */}
          <div
            ref={vinyl}
            className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 h-[78%] w-[78%] rounded-full"
            style={{
              background:
                "repeating-radial-gradient(circle, #111 0 3px, #1a1a1a 3px 6px), radial-gradient(circle, #0b0b0b, #000)",
              boxShadow:
                "0 30px 80px -10px rgba(0,0,0,0.7), inset 0 0 0 8px #0a0a0a",
            }}
          >
            <div
              className="absolute inset-0 rounded-full pointer-events-none"
              style={{
                background:
                  "linear-gradient(120deg, transparent 40%, rgba(255,255,255,0.12) 50%, transparent 60%)",
              }}
            />
            <div
              className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 h-1/3 w-1/3 rounded-full grid place-items-center"
              style={{ background: "var(--color-accent)" }}
            >
              <div className="text-center">
                <div className="font-display text-[10px] tracking-[0.35em] text-accent-foreground">AT LIVE</div>
                <div className="font-script text-lg text-accent-foreground -mt-0.5">side A</div>
              </div>
              <div className="absolute h-3 w-3 rounded-full bg-foreground" />
            </div>
          </div>

          {/* floating coffee cup */}
          <div
            ref={cup}
            className="absolute -left-2 sm:left-4 top-6 will-change-transform"
            style={{ transform: "translateZ(60px)" }}
          >
            <div className="relative h-24 w-24 sm:h-32 sm:w-32">
              <div
                className="absolute inset-0 rounded-b-[40%] rounded-t-[10%] bg-secondary"
                style={{ boxShadow: "0 20px 40px -10px rgba(0,0,0,0.5), inset -8px -6px 0 rgba(0,0,0,0.15)" }}
              />
              <div className="absolute top-3 left-3 right-3 h-4 rounded-full bg-[#6f4a2e]" />
              <div className="absolute -right-4 top-1/2 -translate-y-1/2 h-10 w-6 rounded-r-full border-4 border-secondary" />
              <div className="absolute -top-4 left-4 h-8 w-2 rounded-full bg-background/40 blur-sm rotate-12" />
              <div className="absolute -top-6 left-9 h-10 w-2 rounded-full bg-background/30 blur-sm -rotate-6" />
            </div>
            <div className="mt-1 font-script text-secondary text-lg text-center">hot ☕</div>
          </div>

          {/* floating pizza slice */}
          <div
            ref={slice}
            className="absolute right-0 sm:-right-4 bottom-4 will-change-transform"
            style={{ transform: "translateZ(90px)" }}
          >
            <svg width="140" height="140" viewBox="0 0 140 140" className="drop-shadow-[0_20px_30px_rgba(0,0,0,0.5)]">
              <defs>
                <linearGradient id="crust" x1="0" x2="1">
                  <stop offset="0" stopColor="#e2b678" />
                  <stop offset="1" stopColor="#b17a3a" />
                </linearGradient>
              </defs>
              <polygon points="70,10 130,130 10,130" fill="url(#crust)" stroke="#8a5a24" strokeWidth="3" strokeLinejoin="round" />
              <polygon points="70,20 122,124 18,124" fill="#f2d097" />
              <circle cx="60" cy="80" r="10" fill="#c33232" />
              <circle cx="92" cy="70" r="9" fill="#c33232" />
              <circle cx="78" cy="108" r="9" fill="#c33232" />
              <circle cx="45" cy="115" r="5" fill="#6aa84f" />
              <circle cx="100" cy="110" r="5" fill="#6aa84f" />
              <circle cx="70" cy="55" r="5" fill="#6aa84f" />
            </svg>
            <div className="-mt-2 font-script text-secondary text-lg text-center">wood fired</div>
          </div>

          {/* orbit dots */}
          {[0, 72, 144, 216, 288].map((deg) => (
            <div
              key={deg}
              className="absolute left-1/2 top-1/2 h-2 w-2 rounded-full bg-secondary"
              style={{
                transform: `translate(-50%, -50%) rotate(${deg}deg) translateY(-190px)`,
                animation: "spin-slow 20s linear infinite",
              }}
            />
          ))}
        </div>
      </div>
    </section>
  );
}

function SignatureCarousel() {
  const picks = MENU.filter((m) => m.chefPick).slice(0, 8);
  const list = picks.length ? picks : MENU.slice(0, 8);
  const track = [...list, ...list];
  return (
    <section className="py-20 sm:py-24 bg-secondary/40 overflow-hidden border-y-2 border-foreground/10">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 flex items-end justify-between flex-wrap gap-4">
        <div>
          <div className="text-xs tracking-[0.35em] text-accent">CHEF'S PICKS</div>
          <h2 className="mt-3 font-display text-4xl sm:text-5xl uppercase leading-[0.95]">
            Signature plates.<br />Straight from the fire.
          </h2>
        </div>
        <Link to="/menu" className="inline-flex items-center gap-1 text-sm font-medium hover:text-accent">
          Full menu <ChevronRight className="h-4 w-4" />
        </Link>
      </div>
      <div className="mt-10 relative">
        <div className="flex gap-6 animate-[marquee_40s_linear_infinite] w-max">
          {track.map((m, i) => (
            <Link
              key={i}
              to="/menu/$slug"
              params={{ slug: m.slug }}
              className="polaroid w-64 shrink-0"
              style={{ ["--tilt" as any]: `${(i % 2 === 0 ? -2 : 2)}deg` }}
            >
              <img src={m.img} alt={m.name} className="w-full h-64 object-cover" />
              <div className="p-3">
                <div className="font-display uppercase text-sm truncate">{m.name}</div>
                <div className="text-[10px] tracking-widest text-foreground/60">{m.category.toUpperCase()}</div>
              </div>
            </Link>
          ))}
        </div>
      </div>
      <style>{`@keyframes marquee { from { transform: translateX(0) } to { transform: translateX(-50%) } }`}</style>
    </section>
  );
}

/* ============ Hours Timeline ============ */
function HoursTimeline() {
  const slots = [
    { icon: Sun,    time: "12:00 – 4:00 PM",  title: "LUNCH HOUR",    note: "Business lunch, quick bites, filter coffee." },
    { icon: Coffee, time: "4:00 – 7:00 PM",   title: "CAFE HOURS",    note: "Coffee, cakes, shakes, small plates." },
    { icon: Sunset, time: "7:00 – 10:00 PM",  title: "LIVE SETS",     note: "Gazal · Sufi · Bollywood · Acoustic on stage." },
    { icon: Moon,   time: "10:00 PM – 12 AM", title: "LATE NIGHTS",   note: "Cocktails, sangria, DJ nights on weekends." },
  ];
  return (
    <section className="py-20 sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="max-w-2xl">
          <div className="text-xs tracking-[0.35em] text-accent">A DAY AT AT LIVE</div>
          <h2 className="mt-3 font-display text-4xl sm:text-5xl uppercase leading-[0.95]">
            Open noon till midnight.
          </h2>
          <p className="mt-3 text-foreground/70">
            Four different moods, one address. Whatever hour you drop in, we're cooking, brewing and probably tuning a mic.
          </p>
        </div>
        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {slots.map(({ icon: Icon, time, title, note }, i) => (
            <motion.div
              key={title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
              className="relative p-6 border-2 border-dashed border-foreground/40 rounded-2xl bg-card hover:bg-secondary/50 transition-colors"
            >
              <div className="absolute -top-3 left-6 bg-background px-2 text-[10px] tracking-[0.3em] text-foreground/60">
                {String(i + 1).padStart(2, "0")}
              </div>
              <Icon className="h-8 w-8 text-accent" />
              <div className="mt-3 font-display uppercase text-xl">{title}</div>
              <div className="text-xs tracking-widest text-foreground/60 mt-1">{time}</div>
              <p className="mt-3 text-sm text-foreground/70">{note}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ============ Private Events / Bento ============ */
function PrivateEvents() {
  const items = [
    { icon: CakeIcon,      title: "Birthdays",      note: "Cake cutting, custom playlist, decor packages from ₹2,999." },
    { icon: HeartHandshake,title: "Anniversaries",  note: "A quiet corner, a live gazal set, a menu just for two." },
    { icon: Users,         title: "Team Offsites",  note: "Whole cafe buyouts up to 90 pax with AV and stage." },
    { icon: Mic,           title: "Album Launches", note: "Green room, monitors, PA — plug in and play." },
    { icon: Gift,          title: "Baby Showers",   note: "Afternoon slots, mocktails, and a soft acoustic set." },
    { icon: Sparkles,      title: "Brand Nights",   note: "Popups, tastings, launches — we host the room." },
  ];
  return (
    <section className="py-20 sm:py-28 relative overflow-hidden">
      <div className="absolute inset-0 -z-10 opacity-[0.04]" style={{ backgroundImage: "radial-gradient(currentColor 1px, transparent 1px)", backgroundSize: "22px 22px" }} />
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="flex items-end justify-between flex-wrap gap-4">
          <div className="max-w-2xl">
            <div className="text-xs tracking-[0.35em] text-accent">HOST WITH US</div>
            <h2 className="mt-3 font-display text-4xl sm:text-5xl uppercase leading-[0.95]">
              Private events,<br />done properly.
            </h2>
            <p className="mt-3 text-foreground/70">
              From a table of six to a full buyout — same kitchen, same bar, plus a stage that's already
              wired for a live set.
            </p>
          </div>
          <Link to="/contact" className="inline-flex items-center gap-2 bg-foreground text-background font-display px-6 py-3">
            ENQUIRE <ArrowUpRight className="h-4 w-4" />
          </Link>
        </div>
        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {items.map(({ icon: Icon, title, note }, i) => (
            <motion.div
              key={title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
              className={`p-6 rounded-2xl border-2 border-foreground/10 ${i % 3 === 0 ? "bg-accent text-accent-foreground" : i % 3 === 1 ? "bg-secondary" : "bg-card"}`}
            >
              <Icon className="h-7 w-7" />
              <div className="mt-3 font-display uppercase text-xl">{title}</div>
              <p className="mt-2 text-sm opacity-80">{note}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ============ Amenities Grid ============ */
function AmenitiesGrid() {
  const items = [
    { icon: Wifi,          label: "Free Wi-Fi" },
    { icon: ParkingCircle, label: "Valet Parking" },
    { icon: Wind,          label: "Fully AC" },
    { icon: CreditCard,    label: "All Cards / UPI" },
    { icon: Baby,          label: "Family Friendly" },
    { icon: PawPrint,      label: "Pet Friendly" },
    { icon: Cigarette,     label: "Smoking Zone" },
    { icon: Music,         label: "Live Stage · Daily" },
  ];
  return (
    <section className="py-16 bg-card">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="text-xs tracking-[0.35em] text-accent text-center">GOOD TO KNOW</div>
        <h2 className="mt-2 font-display text-3xl sm:text-4xl uppercase text-center">The little details</h2>
        <div className="mt-10 grid grid-cols-2 sm:grid-cols-4 gap-4">
          {items.map(({ icon: Icon, label }, i) => (
            <motion.div
              key={label}
              initial={{ opacity: 0, y: 12 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.03 }}
              className="flex flex-col items-center gap-2 p-5 border-2 border-foreground/10 rounded-xl bg-background hover:border-accent transition-colors"
            >
              <Icon className="h-6 w-6 text-accent" />
              <div className="text-xs font-display tracking-widest text-center">{label.toUpperCase()}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}


/* ============ FAQ ============ */
function FaqSection() {
  const faqs = [
    { q: "Do I need to book a table?", a: "Weekends fill up by 8 PM — we strongly recommend booking. Weekdays are usually walk-in friendly." },
    { q: "Is there a cover charge for live music?", a: "Most nights are zero cover. Special ticketed nights and festival gigs are announced on the events page." },
    { q: "Can I host a private event?", a: "Yes — from a 6-seater booking to a full buyout for up to 90 guests. Drop us a line on the contact page." },
    { q: "Is the menu vegetarian friendly?", a: "Half the menu is pure veg, clearly marked. We also handle Jain and gluten-free requests with a heads up." },
    { q: "Where exactly are you?", a: "HA-22, Block A, Sector 104, Hajipur, Noida 201304. Valet parking on site." },
    { q: "Do you serve alcohol?", a: "Yes, full bar — cocktails, wines, sangrias, craft beer and a rotating cocktail menu." },
  ];
  const [open, setOpen] = useState<number | null>(0);
  return (
    <section className="py-20 sm:py-28 bg-secondary/50">
      <div className="mx-auto max-w-4xl px-4 sm:px-6">
        <div className="text-center">
          <div className="text-xs tracking-[0.35em] text-accent">BEFORE YOU COME</div>
          <h2 className="mt-3 font-display text-4xl sm:text-5xl uppercase">FAQs</h2>
        </div>
        <div className="mt-10 space-y-3">
          {faqs.map((f, i) => {
            const isOpen = open === i;
            return (
              <div key={i} className="paper p-0 overflow-hidden">
                <button
                  onClick={() => setOpen(isOpen ? null : i)}
                  className="w-full flex items-center justify-between gap-4 px-5 py-4 text-left"
                >
                  <span className="font-display uppercase text-base sm:text-lg">{f.q}</span>
                  {isOpen ? <Minus className="h-4 w-4 shrink-0" /> : <Plus className="h-4 w-4 shrink-0" />}
                </button>
                <motion.div
                  initial={false}
                  animate={{ height: isOpen ? "auto" : 0, opacity: isOpen ? 1 : 0 }}
                  transition={{ duration: 0.25 }}
                  className="overflow-hidden"
                >
                  <p className="px-5 pb-5 text-sm text-foreground/70 leading-relaxed">{f.a}</p>
                </motion.div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

/* ============ Visit Strip (find us) ============ */
function VisitStrip() {
  return (
    <section className="py-20 sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 grid lg:grid-cols-5 gap-8 items-stretch">
        <div className="lg:col-span-2 space-y-4">
          <div className="text-xs tracking-[0.35em] text-accent">FIND US</div>
          <h2 className="font-display text-4xl sm:text-5xl uppercase leading-[0.95]">
            HA-22, Sector 104<br />Hajipur, Noida.
          </h2>
          <p className="text-foreground/70 max-w-md">
            Ten minutes from Sector 18 metro, right off the main road. Look for the neon guitar.
          </p>
          <div className="grid sm:grid-cols-2 gap-3 pt-2">
            <a href="https://maps.google.com" target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 bg-foreground text-background font-display px-5 py-3 justify-center">
              <MapPin className="h-4 w-4" /> GET DIRECTIONS
            </a>
            <a href="tel:+919319322100" className="inline-flex items-center gap-2 border-2 border-foreground font-display px-5 py-3 justify-center">
              <Phone className="h-4 w-4" /> CALL US
            </a>
          </div>
          <div className="pt-4 flex items-center gap-2 text-sm">
            <Clock className="h-4 w-4 text-accent" />
            <span className="tracking-widest">OPEN DAILY · 12:00 – 00:00</span>
          </div>
        </div>
        <div className="lg:col-span-3 rounded-2xl overflow-hidden border-2 border-foreground/10 min-h-[360px]">
          <iframe
            title="AT Live Cafe map"
            src="https://www.google.com/maps?q=Sector+104+Hajipur+Noida&output=embed"
            className="w-full h-full min-h-[360px]"
            loading="lazy"
          />
        </div>
      </div>
    </section>
  );
}

function _default() {
  const [active, setActive] = useState<ChipKey>("all");
  return (
    <>
      <Hero />
      <EventsSection active={active} />
      <CommunitySection />
      <InstagramEmbed />
      <FeaturedArtists />
      <ChipRow active={active} onChange={setActive} />
      <MenuPreview active={active} />
      <ClientOnly fallback={<div className="h-24" />}>
        <GsapMarquee />
      </ClientOnly>
      <ClientOnly fallback={<div className="h-[600px]" />}>
        <Interactive3DShowcase />
      </ClientOnly>
      <SignatureCarousel />
      <HoursTimeline />
      <Ciao />
      <PrivateEvents />
      <Awards />
      <AmenitiesGrid />
      <ReviewsStrip />
      <FaqSection />
      <VisitStrip />
      <ReserveStrip />

    </>
  );
}