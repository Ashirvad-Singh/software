import { useEffect, useRef } from "react";
import { motion } from "motion/react";
import { Instagram, ExternalLink } from "lucide-react";

export default function InstagramEmbed() {
  const glowRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    let rafId: number;
    const glow = glowRef.current;
    if (!glow) return;

    let t = 0;
    const animate = () => {
      t += 0.008;
      const x = Math.sin(t) * 12;
      const y = Math.cos(t * 0.7) * 10;
      glow.style.transform = `translate(${x}px, ${y}px)`;
      rafId = requestAnimationFrame(animate);
    };
    rafId = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(rafId);
  }, []);

  return (
    <section className="relative py-16 sm:py-24 overflow-hidden bg-section-light-bg text-section-light-text">
      {/* subtle grid — scales with current text color */}
      <div
        className="absolute inset-0 opacity-[0.06] pointer-events-none text-section-light-text"
        style={{
          backgroundImage:
            "linear-gradient(currentColor 1px, transparent 1px), linear-gradient(90deg, currentColor 1px, transparent 1px)",
          backgroundSize: "44px 44px",
        }}
      />

      {/* drifting pink blur orbs */}
      <div
        ref={glowRef}
        className="absolute -top-24 -left-24 w-[420px] h-[420px] rounded-full pointer-events-none animate-float-slow"
        style={{
          background:
            "radial-gradient(circle at 50% 50%, oklch(0.72 0.22 350 / 0.22), transparent 65%)",
          filter: "blur(60px)",
        }}
      />
      <div
        className="absolute -bottom-32 -right-24 w-[360px] h-[360px] rounded-full pointer-events-none animate-float-slow-reverse"
        style={{
          background:
            "radial-gradient(circle at 50% 50%, oklch(0.75 0.24 355 / 0.16), transparent 65%)",
          filter: "blur(60px)",
        }}
      />

      <div className="relative mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-6 mb-8 sm:mb-10">
          <div className="max-w-xl">
            <div className="inline-flex items-center gap-2 text-xs tracking-[0.35em] text-primary mb-3">
              <Instagram className="w-4 h-4" /> @ATLIVENOIDA
            </div>
            <h2 className="font-display text-3xl sm:text-5xl lg:text-6xl uppercase leading-[0.95]">
              Follow the feed.
            </h2>
            <p className="mt-3 text-section-light-muted max-w-md text-sm sm:text-base">
              Reels, plates, and behind-the-scenes from Sector 104 — straight from our Instagram.
            </p>
          </div>
          <a
            href="https://www.instagram.com/atlivenoida/"
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center justify-center gap-2 bg-primary text-primary-foreground font-display px-6 py-3 hover:bg-accent transition-colors shrink-0"
          >
            <Instagram className="h-4 w-4" /> OPEN PROFILE <ExternalLink className="h-3.5 w-3.5" />
          </a>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="relative rounded-2xl border-2 border-section-light-border bg-section-light-bg p-2 sm:p-3 shadow-[0_30px_80px_-30px_rgba(0,0,0,0.18)]"
        >
          {/* mobile-first responsive iframe wrapper with correct Instagram aspect ratio */}
          <div className="relative w-full overflow-hidden rounded-xl bg-section-light-bg aspect-[4/5] sm:aspect-[3/4] md:aspect-square lg:aspect-[4/3]">
            <iframe
              title="AT Live Noida Instagram"
              src="https://www.instagram.com/atlivenoida/embed/?cr=1&v=14&wp=1080&rd=https%3A%2F%2Fwww.instagram.com&rp=%2F"
              className="absolute inset-0 w-full h-full border-0"
              allowTransparency
              allowFullScreen
              loading="lazy"
            />
          </div>
        </motion.div>
      </div>
    </section>
  );
}
