import { useCallback, useEffect, useState } from "react";
import useEmblaCarousel from "embla-carousel-react";
import { Link } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight, Music, MapPin, Sparkles } from "lucide-react";
import { ARTISTS } from "@/data/artists";

export default function FeaturedArtists() {
  const [emblaRef, embla] = useEmblaCarousel({
    loop: true,
    align: "start",
    dragFree: true,
    containScroll: "trimSnaps",
  });
  const [canPrev, setCanPrev] = useState(false);
  const [canNext, setCanNext] = useState(false);

  const onSelect = useCallback(() => {
    if (!embla) return;
    setCanPrev(embla.canScrollPrev());
    setCanNext(embla.canScrollNext());
  }, [embla]);

  useEffect(() => {
    if (!embla) return;
    onSelect();
    embla.on("select", onSelect);
    embla.on("reInit", onSelect);
  }, [embla, onSelect]);

  return (
    <section className="relative bg-background text-foreground py-16 sm:py-24 overflow-hidden">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="flex items-end justify-between gap-6 flex-wrap">
          <div>
            <div className="inline-flex items-center gap-2 text-[11px] tracking-[0.35em] text-primary uppercase">
              <Sparkles className="h-3.5 w-3.5" /> On our stage
            </div>
            <h2 className="mt-2 font-display uppercase text-4xl sm:text-6xl leading-[0.9]">
              Featured <span className="text-accent">artists</span>
            </h2>
            <p className="mt-3 font-script text-2xl text-foreground/70 max-w-xl">
              the voices you actually come back for
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => embla?.scrollPrev()}
              disabled={!canPrev}
              aria-label="Previous artist"
              className="grid h-11 w-11 place-items-center rounded-full border-2 border-foreground bg-background hover:bg-foreground hover:text-background transition disabled:opacity-30"
            >
              <ArrowLeft className="h-4 w-4" />
            </button>
            <button
              onClick={() => embla?.scrollNext()}
              disabled={!canNext}
              aria-label="Next artist"
              className="grid h-11 w-11 place-items-center rounded-full bg-primary text-primary-foreground border-2 border-primary hover:opacity-90 transition disabled:opacity-40"
            >
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </div>

        <div className="mt-8 sm:mt-10 -mx-4 sm:mx-0" ref={emblaRef}>
          <div className="flex gap-5 sm:gap-6 px-4 sm:px-0">
            {ARTISTS.map((a, i) => {
              const tilts = ["-2deg", "1.5deg", "-1deg", "2deg", "-1.5deg", "1deg"];
              return (
                <Link
                  key={a.slug}
                  to="/events/$eventId"
                  params={{ eventId: a.eventSlug }}
                  className="group shrink-0 w-[78vw] sm:w-[340px] md:w-[360px]"
                >
                  <div
                    className="polaroid relative"
                    style={{ ["--tilt" as any]: tilts[i % tilts.length] }}
                  >
                    <div className="relative overflow-hidden">
                      <img
                        src={a.img}
                        alt={a.name}
                        className="w-full h-[360px] sm:h-[400px] object-cover transition-transform duration-700 group-hover:scale-105"
                        loading="lazy"
                      />
                      <span className="absolute top-3 left-3 bg-primary text-primary-foreground text-[10px] tracking-[0.28em] px-2.5 py-1 font-display uppercase">
                        {a.genre}
                      </span>
                      <span className="absolute top-3 right-3 bg-background/90 backdrop-blur text-foreground text-[10px] tracking-[0.22em] px-2 py-1 inline-flex items-center gap-1">
                        <Music className="h-3 w-3" /> {a.shows} shows
                      </span>
                      <div className="absolute inset-x-0 bottom-0 h-32 bg-gradient-to-t from-foreground/85 to-transparent" />
                      <div className="absolute inset-x-0 bottom-0 p-4 text-background">
                        <div className="font-display text-2xl uppercase leading-none">{a.name}</div>
                        <div className="mt-1.5 text-[11px] tracking-[0.2em] uppercase text-background/80 inline-flex items-center gap-1">
                          <MapPin className="h-3 w-3" /> {a.city}
                        </div>
                      </div>
                    </div>
                    <div className="mt-3 px-1 pb-1 flex items-center justify-between">
                      <div className="font-script text-xl text-foreground/80">{a.tag}</div>
                      <span className="text-[11px] tracking-[0.25em] uppercase text-primary font-display">
                        View →
                      </span>
                    </div>
                  </div>
                </Link>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
