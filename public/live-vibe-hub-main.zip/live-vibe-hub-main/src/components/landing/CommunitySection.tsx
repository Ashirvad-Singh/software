import { Link } from "@tanstack/react-router";
import { motion } from "motion/react";
import { Mic, Camera, HeartHandshake, Music, Users, ArrowUpRight, Quote, Sparkles } from "lucide-react";
import a1 from "@/assets/artist-1.jpg";
import a2 from "@/assets/artist-2.jpg";
import a3 from "@/assets/artist-3.jpg";

const STORIES = [
  {
    name: "Ananya R.",
    role: "Open Mic regular",
    img: a1,
    quote:
      "Walked in for a coffee, ended up reading my poetry on stage. This place has a way of pulling you in.",
  },
  {
    name: "Kavish B.",
    role: "Resident gazal artist",
    img: a2,
    quote:
      "AT Live gave me my first paid gig. Two years later, the same corner table cheers me on every Thursday.",
  },
  {
    name: "Sana & Rohit",
    role: "Photo Friday hosts",
    img: a3,
    quote:
      "We met at a jam night here. Now we host film-photography meets in the same room. Full circle.",
  },
];

const WAYS = [
  { icon: Mic,           title: "Open Mic Tuesdays", desc: "Sign the chalkboard by 7pm. 6 minutes, any language, any craft.", cta: "Reserve a seat", to: "/reserve" as const },
  { icon: Camera,        title: "Photo Fridays",     desc: "Film & phone photographers swap rolls over slow coffee.",         cta: "See gallery",   to: "/reviews" as const },
  { icon: Music,         title: "Artist Residency",  desc: "Pitch a 4-week Thursday set. We host, promote and pay.",          cta: "Apply now",     to: "/reserve" as const },
  { icon: HeartHandshake,title: "Cause Nights",      desc: "One Sunday a month — proceeds to a local cause you nominate.",    cta: "Nominate",      to: "/reserve" as const },
];

export default function CommunitySection() {
  return (
    <section id="community" className="relative bg-background py-20 sm:py-28 border-t-2 border-foreground/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-6 mb-14">
          <div>
            <div className="inline-flex items-center gap-2 text-xs tracking-[0.35em] text-primary mb-4">
              <Sparkles className="w-4 h-4" /> COMMUNITY
            </div>
            <h2 className="font-display text-5xl sm:text-7xl leading-none">
              Join the <span className="italic text-primary">circle</span>.
            </h2>
            <p className="mt-4 max-w-xl text-foreground/70">
              AT Live isn't just a cafe — it's a room of regulars, artists and first-timers who keep showing up. Here's who's here, and how you plug in.
            </p>
          </div>
          <div className="flex gap-6 text-center">
            {[
              { n: "1.2k", l: "Regulars" },
              { n: "80+",  l: "Artists" },
              { n: "300+", l: "Nights" },
            ].map((s) => (
              <div key={s.l}>
                <div className="font-display text-4xl text-primary leading-none">{s.n}</div>
                <div className="text-[10px] tracking-[0.3em] text-foreground/60 mt-1">{s.l}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Member stories */}
        <div className="mb-20">
          <div className="flex items-center gap-3 mb-6">
            <Users className="w-5 h-5 text-primary" />
            <h3 className="font-display text-2xl sm:text-3xl">Member stories</h3>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {STORIES.map((s, i) => (
              <motion.article
                key={s.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="relative bg-secondary/40 border-2 border-foreground/10 p-6 hover:border-primary transition-colors"
              >
                <Quote className="absolute top-4 right-4 w-8 h-8 text-primary/20" />
                <div className="flex items-center gap-3 mb-4">
                  <img src={s.img} alt={s.name} className="w-12 h-12 rounded-full object-cover border-2 border-primary" />
                  <div>
                    <div className="font-semibold">{s.name}</div>
                    <div className="text-[10px] tracking-[0.3em] text-foreground/60">{s.role.toUpperCase()}</div>
                  </div>
                </div>
                <p className="text-sm text-foreground/80 leading-relaxed italic">"{s.quote}"</p>
              </motion.article>
            ))}
          </div>
        </div>

        {/* How to participate */}
        <div>
          <div className="flex items-center gap-3 mb-6">
            <HeartHandshake className="w-5 h-5 text-primary" />
            <h3 className="font-display text-2xl sm:text-3xl">How to participate</h3>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {WAYS.map((w, i) => (
              <motion.div
                key={w.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.06 }}
                className="group relative bg-background border-2 border-foreground p-6 hover:bg-foreground hover:text-background transition-colors"
              >
                <w.icon className="w-8 h-8 mb-4 text-primary group-hover:text-primary" />
                <div className="font-display text-xl mb-2">{w.title}</div>
                <p className="text-sm opacity-80 mb-5">{w.desc}</p>
                <Link
                  to={w.to}
                  className="inline-flex items-center gap-1 text-xs tracking-[0.3em] border-b border-current pb-0.5"
                >
                  {w.cta.toUpperCase()} <ArrowUpRight className="w-3 h-3" />
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
