import { useEffect, useMemo, useState } from "react";
import {
  Calendar as CalendarIcon, Minus, Plus, Ticket, Loader2, CheckCircle2,
  Mail, BellRing, MapPin, Clock, Download, Share2,
} from "lucide-react";
import { format } from "date-fns";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Calendar } from "@/components/ui/calendar";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

type RazorpayResponse = { razorpay_payment_id: string; razorpay_order_id?: string; razorpay_signature?: string };

declare global {
  interface Window {
    Razorpay?: new (opts: Record<string, unknown>) => { open: () => void };
  }
}

function loadRazorpay(): Promise<boolean> {
  return new Promise((resolve) => {
    if (typeof window === "undefined") return resolve(false);
    if (window.Razorpay) return resolve(true);
    const s = document.createElement("script");
    s.src = "https://checkout.razorpay.com/v1/checkout.js";
    s.onload = () => resolve(true);
    s.onerror = () => resolve(false);
    document.body.appendChild(s);
  });
}

export type BookingIntent = {
  kind: "event" | "table";
  title: string;
  subtitle?: string;
  pricePerSeat: number; // in INR
  defaultDate?: Date;
  eventSlug?: string;
};

export function BookingDialog({
  open,
  onOpenChange,
  intent,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  intent: BookingIntent;
}) {
  const [date, setDate] = useState<Date | undefined>(intent.defaultDate ?? new Date());
  const [seats, setSeats] = useState(2);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState<RazorpayResponse | null>(null);
  const [notifState, setNotifState] = useState<"idle" | "granted" | "denied" | "unsupported">("idle");

  useEffect(() => {
    if (typeof window === "undefined" || !("Notification" in window)) {
      setNotifState("unsupported");
    }
  }, []);

  const bookingId = useMemo(
    () => `ATL-${Math.random().toString(36).slice(2, 6).toUpperCase()}-${Date.now().toString().slice(-4)}`,
    [done],
  );

  async function requestPush() {
    if (!("Notification" in window)) return;
    try {
      const perm = await Notification.requestPermission();
      if (perm === "granted") {
        setNotifState("granted");
        new Notification("AT Live Cafe — Booking confirmed 🎶", {
          body: `${intent.title} · ${date ? format(date, "PPP") : ""} · ${seats} seat${seats > 1 ? "s" : ""}`,
          icon: "/atlive-logo.png",
          badge: "/atlive-logo.png",
          tag: bookingId,
        });
        toast.success("You'll get a reminder before the show.");
      } else {
        setNotifState("denied");
        toast("Notifications blocked. You can enable them from your browser settings.");
      }
    } catch {
      setNotifState("denied");
    }
  }

  useEffect(() => {
    if (open) {
      setDone(null);
      setDate(intent.defaultDate ?? new Date());
      setSeats(intent.kind === "event" ? 2 : 2);
    }
  }, [open, intent]);

  const total = useMemo(() => intent.pricePerSeat * seats, [intent.pricePerSeat, seats]);
  const canPay = !!date && seats > 0 && name.trim().length > 1 && /^\+?\d[\d\s-]{7,}$/.test(phone);

  async function handlePay() {
    if (!canPay || !date) return;
    setLoading(true);
    const ok = await loadRazorpay();
    if (!ok || !window.Razorpay) {
      toast.error("Payment SDK failed to load");
      setLoading(false);
      return;
    }
    const keyId = (import.meta.env.VITE_RAZORPAY_KEY_ID as string | undefined) || "";
    if (!keyId) {
      toast.error("Razorpay key missing — connect Razorpay in project secrets to accept live payments.");
      setLoading(false);
      return;
    }
    const rzp = new window.Razorpay({
      key: keyId,
      amount: total * 100,
      currency: "INR",
      name: "AT Live Cafe",
      description: `${intent.kind === "event" ? "Show + Table" : "Table Reservation"} · ${intent.title}`,
      image: "/atlive-logo.png",
      prefill: { name, contact: phone, email },
      notes: {
        booking_kind: intent.kind,
        event: intent.eventSlug ?? "",
        date: format(date, "yyyy-MM-dd"),
        seats: String(seats),
      },
      theme: { color: "#ec4899" },
      handler: (response: RazorpayResponse) => {
        setLoading(false);
        setDone(response);
        toast.success("Booking confirmed! We'll message you the ticket.");
      },
      modal: {
        ondismiss: () => setLoading(false),
      },
    });
    rzp.open();
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl p-0 overflow-hidden bg-card border-foreground/10">
        {done ? (
          <ConfirmationEmail
            bookingId={bookingId}
            payment={done}
            intent={intent}
            date={date}
            seats={seats}
            total={total}
            name={name}
            email={email}
            notifState={notifState}
            onEnablePush={requestPush}
            onClose={() => onOpenChange(false)}
          />
        ) : (
          <div className="grid md:grid-cols-[1.05fr_1fr]">
            {/* Calendar side */}
            <div className="bg-secondary/40 p-6 border-r border-foreground/10">
              <div className="text-[11px] uppercase tracking-widest text-primary">Pick a date</div>
              <DialogHeader className="mt-1">
                <DialogTitle className="text-2xl">{intent.title}</DialogTitle>
                {intent.subtitle && (
                  <DialogDescription className="text-foreground/60">{intent.subtitle}</DialogDescription>
                )}
              </DialogHeader>
              <div className="mt-4 rounded-2xl bg-background border border-foreground/10 p-2">
                <Calendar
                  mode="single"
                  selected={date}
                  onSelect={setDate}
                  disabled={{ before: new Date() }}
                  className="pointer-events-auto"
                />
              </div>
              <div className="mt-3 text-xs text-foreground/60 inline-flex items-center gap-1.5">
                <CalendarIcon className="h-3.5 w-3.5" />
                {date ? format(date, "EEEE, MMM d, yyyy") : "Select a date"}
              </div>
            </div>

            {/* Form side */}
            <div className="p-6 flex flex-col">
              <div className="text-[11px] uppercase tracking-widest text-foreground/50">Seats & guest</div>
              <div className="mt-3 flex items-center justify-between rounded-2xl bg-secondary/40 border border-foreground/10 px-4 py-3">
                <div>
                  <div className="text-sm font-medium inline-flex items-center gap-1.5"><Ticket className="h-4 w-4" /> Seats</div>
                  <div className="text-xs text-foreground/60">₹{intent.pricePerSeat} per seat</div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    className="grid h-9 w-9 place-items-center rounded-full bg-background border border-foreground/10 disabled:opacity-40"
                    onClick={() => setSeats((s) => Math.max(1, s - 1))}
                    disabled={seats <= 1}
                    aria-label="Decrease"
                  >
                    <Minus className="h-4 w-4" />
                  </button>
                  <div className="w-8 text-center text-lg font-semibold">{seats}</div>
                  <button
                    className="grid h-9 w-9 place-items-center rounded-full bg-primary text-primary-foreground"
                    onClick={() => setSeats((s) => Math.min(20, s + 1))}
                    aria-label="Increase"
                  >
                    <Plus className="h-4 w-4" />
                  </button>
                </div>
              </div>

              <div className="mt-4 space-y-3">
                <div>
                  <label className="text-xs text-foreground/60">Full name</label>
                  <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Aarav Sharma" className="mt-1" />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs text-foreground/60">Phone</label>
                    <Input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+91 98xxxxxxxx" className="mt-1" />
                  </div>
                  <div>
                    <label className="text-xs text-foreground/60">Email (optional)</label>
                    <Input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@email.com" className="mt-1" />
                  </div>
                </div>
              </div>

              <div className="mt-auto pt-6">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-foreground/60">Subtotal</span>
                  <span>₹{total}</span>
                </div>
                <div className="flex items-center justify-between text-xs text-foreground/50 mt-1">
                  <span>Taxes & fees</span>
                  <span>Included</span>
                </div>
                <Button
                  onClick={handlePay}
                  disabled={!canPay || loading}
                  className="mt-4 w-full h-12 rounded-full bg-primary text-primary-foreground text-base font-semibold hover:opacity-90"
                >
                  {loading ? (
                    <><Loader2 className="h-4 w-4 animate-spin" /> Opening Razorpay…</>
                  ) : (
                    <>Pay ₹{total} with Razorpay</>
                  )}
                </Button>
                <p className="mt-2 text-[11px] text-foreground/50 text-center">
                  Secure payments by Razorpay · Free cancellation up to 24h before.
                </p>
              </div>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

function ConfirmationEmail({
  bookingId, payment, intent, date, seats, total, name, email, notifState, onEnablePush, onClose,
}: {
  bookingId: string;
  payment: RazorpayResponse;
  intent: BookingIntent;
  date: Date | undefined;
  seats: number;
  total: number;
  name: string;
  email: string;
  notifState: "idle" | "granted" | "denied" | "unsupported";
  onEnablePush: () => void;
  onClose: () => void;
}) {
  const when = date ? format(date, "EEEE, MMMM d, yyyy") : "—";

  async function share() {
    const text = `Booked ${intent.title} at AT Live Cafe on ${when}. Booking ${bookingId}.`;
    if (navigator.share) {
      try { await navigator.share({ title: "AT Live Cafe booking", text }); return; } catch { /* dismissed */ }
    }
    try {
      await navigator.clipboard.writeText(text);
      toast.success("Booking details copied");
    } catch {
      toast("Sharing not available on this device");
    }
  }

  return (
    <div className="max-h-[85vh] overflow-y-auto">
      {/* Email envelope */}
      <div className="bg-secondary/40 px-6 py-3 border-b border-foreground/10 flex items-center justify-between">
        <div className="inline-flex items-center gap-2 text-[11px] tracking-[0.28em] uppercase text-foreground/60">
          <Mail className="h-3.5 w-3.5" /> Inbox · AT Live Cafe
        </div>
        <div className="text-[11px] text-foreground/50">just now</div>
      </div>

      <div className="px-6 sm:px-10 py-8 bg-background">
        {/* From/To header */}
        <div className="flex items-start gap-3">
          <div className="grid h-10 w-10 place-items-center rounded-full bg-primary text-primary-foreground font-display text-sm shrink-0">
            AT
          </div>
          <div className="min-w-0 flex-1">
            <div className="text-sm">
              <span className="font-semibold">AT Live Cafe</span>{" "}
              <span className="text-foreground/50">&lt;tickets@atlivecafe.in&gt;</span>
            </div>
            <div className="text-xs text-foreground/50">
              to <span className="text-foreground/80">{name || "you"}</span>
              {email ? <> &lt;{email}&gt;</> : null}
            </div>
          </div>
        </div>

        <div className="mt-6 flex items-center gap-3">
          <CheckCircle2 className="h-8 w-8 text-primary" />
          <DialogTitle className="text-2xl sm:text-3xl font-display uppercase tracking-tight">
            You're on the list 🎶
          </DialogTitle>
        </div>
        <p className="mt-2 text-sm text-foreground/70">
          Hey {name?.split(" ")[0] || "there"}, we've confirmed your booking. See you at the stage.
        </p>

        {/* Ticket card */}
        <div className="mt-6 rounded-2xl border-2 border-dashed border-foreground/20 bg-secondary/30 overflow-hidden">
          <div className="flex items-stretch">
            <div className="hidden sm:flex flex-col justify-between p-5 border-r-2 border-dashed border-foreground/20 bg-primary text-primary-foreground w-40">
              <div>
                <div className="text-[10px] tracking-[0.3em] uppercase opacity-80">Booking</div>
                <div className="font-mono text-sm mt-1">{bookingId}</div>
              </div>
              <div className="text-[10px] tracking-[0.28em] uppercase opacity-80">
                {intent.kind === "event" ? "SHOW + TABLE" : "TABLE"}
              </div>
            </div>
            <div className="flex-1 p-5 sm:p-6">
              <div className="font-display text-xl sm:text-2xl uppercase leading-tight">
                {intent.title}
              </div>
              {intent.subtitle && (
                <div className="mt-1 text-xs text-foreground/60">{intent.subtitle}</div>
              )}
              <div className="mt-4 grid grid-cols-2 gap-4 text-sm">
                <Field icon={CalendarIcon} label="Date" value={when} />
                <Field icon={Clock} label="Doors" value="30 min before show" />
                <Field icon={Ticket} label="Seats" value={`${seats} × ₹${intent.pricePerSeat}`} />
                <Field icon={MapPin} label="Venue" value="Sector 104, Noida" />
              </div>
            </div>
          </div>
          <div className="flex items-center justify-between px-5 sm:px-6 py-3 border-t-2 border-dashed border-foreground/20 bg-background">
            <span className="text-xs text-foreground/60">Total paid</span>
            <span className="font-display text-lg">₹{total}</span>
          </div>
        </div>

        {/* Payment ref */}
        <div className="mt-4 text-xs text-foreground/60 flex items-center justify-between flex-wrap gap-2">
          <span>Payment ID: <span className="font-mono text-foreground/80">{payment.razorpay_payment_id}</span></span>
          <span>Secured by Razorpay</span>
        </div>

        {/* Push notification card */}
        <div className="mt-6 rounded-2xl border border-foreground/10 bg-card p-4 sm:p-5 flex items-start gap-4">
          <div className="grid h-10 w-10 place-items-center rounded-full bg-primary/10 text-primary shrink-0">
            <BellRing className="h-5 w-5" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-sm font-semibold">Get a reminder on show day</div>
            <div className="text-xs text-foreground/60 mt-0.5">
              We'll ping this device 2 hours before doors open. Optional.
            </div>
          </div>
          {notifState === "granted" ? (
            <span className="text-xs font-medium text-primary inline-flex items-center gap-1">
              <CheckCircle2 className="h-4 w-4" /> On
            </span>
          ) : notifState === "unsupported" ? (
            <span className="text-xs text-foreground/50">Not supported</span>
          ) : (
            <Button
              size="sm"
              onClick={onEnablePush}
              className="rounded-full bg-primary text-primary-foreground hover:opacity-90"
            >
              Enable
            </Button>
          )}
        </div>

        {/* Actions */}
        <div className="mt-6 flex flex-wrap gap-2">
          <Button
            onClick={() => window.print()}
            variant="outline"
            className="rounded-full"
          >
            <Download className="h-4 w-4" /> Save receipt
          </Button>
          <Button
            onClick={share}
            variant="outline"
            className="rounded-full"
          >
            <Share2 className="h-4 w-4" /> Share
          </Button>
          <Button
            onClick={onClose}
            className="rounded-full bg-primary text-primary-foreground ml-auto"
          >
            Done
          </Button>
        </div>

        <p className="mt-4 text-[11px] text-foreground/40 text-center">
          A copy of this receipt has been queued to {email || "your registered email"}. Show this screen at the door.
        </p>
      </div>
    </div>
  );
}

function Field({ icon: Icon, label, value }: { icon: React.ComponentType<{ className?: string }>; label: string; value: string }) {
  return (
    <div>
      <div className="text-[10px] tracking-[0.24em] uppercase text-foreground/50 inline-flex items-center gap-1">
        <Icon className="h-3 w-3" /> {label}
      </div>
      <div className="mt-0.5 text-sm text-foreground/90">{value}</div>
    </div>
  );
}