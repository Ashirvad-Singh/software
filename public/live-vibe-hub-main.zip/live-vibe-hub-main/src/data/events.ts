import ev1 from "@/assets/event-1.jpg";
import ev2 from "@/assets/event-2.jpg";
import ev3 from "@/assets/event-3.jpg";
import ev4 from "@/assets/event-4.jpg";
import ev5 from "@/assets/event-5.jpg";
import cafeInterior from "@/assets/cafe-interior.jpg";
import food1 from "@/assets/food-1.jpg";
import food3 from "@/assets/food-3.jpg";

export type EventItem = {
  slug: string;
  img: string;
  gallery: string[];
  artist: string;
  about: string;
  venue: string;
  address: string;
  mapQuery: string;
  date: string;
  time: string;
  doorsOpen: string;
  price: string;
  genre: string;
  seats: number;
  featured?: boolean;
};

const VENUE = "AT Live Cafe · Hajipur, Noida";
const ADDRESS = "HA-22, Block A, Sector 104, Hajipur, Noida 201304";
const MAP_Q = "AT Live Cafe HA-22 Sector 104 Hajipur Noida";

export const EVENTS: EventItem[] = [
  {
    slug: "gazal-nights",
    img: ev1,
    gallery: [ev1, cafeInterior, food3, ev3],
    artist: "Gazal Nights ft. Kavish Bhardwaj",
    about:
      "The AT Live signature — a full gazal evening with tabla, harmonium and a hushed room. Guests consistently call this out in reviews as the reason to come. Full multi-cuisine kitchen and bar open through the set.",
    venue: VENUE,
    address: ADDRESS,
    mapQuery: MAP_Q,
    date: "Every Fri",
    time: "8:30 PM",
    doorsOpen: "7:30 PM · Kitchen open till midnight",
    price: "₹0 cover · ₹600–1,800 pp for food & drink",
    genre: "Gazal",
    seats: 18,
    featured: true,
  },
  {
    slug: "sufi-sundowner",
    img: ev2,
    gallery: [ev2, cafeInterior, food1, ev4],
    artist: "Sufi Sundowner ft. Aman Qawwal",
    about:
      "Rooftop-style Sufi and qawwali on the terrace. Pair with our Chicken Sharabi Tikka and a jug of house sangria.",
    venue: VENUE,
    address: ADDRESS,
    mapQuery: MAP_Q,
    date: "Every Sat",
    time: "8:00 PM",
    doorsOpen: "7:00 PM · Full dinner service",
    price: "₹0 cover",
    genre: "Sufi",
    seats: 22,
    featured: true,
  },
  {
    slug: "acoustic-sundays",
    img: ev3,
    gallery: [ev3, cafeInterior, food3, ev1],
    artist: "Acoustic Sundays",
    about:
      "A rotating line-up of Delhi-NCR singer-songwriters. Sunday brunch menu and bottomless coffee till the last set.",
    venue: VENUE,
    address: ADDRESS,
    mapQuery: MAP_Q,
    date: "Every Sun",
    time: "7:00 PM",
    doorsOpen: "5:00 PM · Brunch & bar menu",
    price: "₹0 cover",
    genre: "Acoustic",
    seats: 30,
    featured: true,
  },
  {
    slug: "open-mic-tuesday",
    img: ev4,
    gallery: [ev4, cafeInterior, food1],
    artist: "Open Mic Tuesday",
    about: "Bring your song, poem or set — we'll bring the room. Free entry with any order.",
    venue: VENUE,
    address: ADDRESS,
    mapQuery: MAP_Q,
    date: "Every Tue",
    time: "8:00 PM",
    doorsOpen: "7:00 PM",
    price: "Free with any order",
    genre: "Open Mic",
    seats: 40,
  },
  {
    slug: "retro-bollywood",
    img: ev5,
    gallery: [ev5, cafeInterior],
    artist: "Retro Bollywood Night",
    about: "A live band takes on 70s–90s Hindi film hits. Full multi-cuisine menu on till midnight.",
    venue: VENUE,
    address: ADDRESS,
    mapQuery: MAP_Q,
    date: "Every Wed",
    time: "9:00 PM",
    doorsOpen: "8:00 PM · Bar & late menu",
    price: "₹0 cover",
    genre: "Bollywood",
    seats: 25,
  },
  {
    slug: "unplugged-thursdays",
    img: ev1,
    gallery: [ev1, cafeInterior, food3],
    artist: "Unplugged Thursdays",
    about: "Slower Thursday — an unplugged singer-songwriter set with our full menu on offer.",
    venue: VENUE,
    address: ADDRESS,
    mapQuery: MAP_Q,
    date: "Every Thu",
    time: "8:30 PM",
    doorsOpen: "7:30 PM",
    price: "₹0 cover",
    genre: "Acoustic",
    seats: 20,
  },
];

export const getEvent = (slug: string) => EVENTS.find((e) => e.slug === slug);
export const getRelated = (slug: string, n = 3) =>
  EVENTS.filter((e) => e.slug !== slug).slice(0, n);