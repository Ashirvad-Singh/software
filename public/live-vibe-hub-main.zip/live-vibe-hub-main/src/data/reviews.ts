export type Review = {
  quote: string;
  who: string;
  source: "Google" | "Zomato" | "Swiggy" | "Justdial";
  rating: number;
  linkTo?: "gazal-nights" | "sufi-sundowner" | "acoustic-sundays" | "open-mic-tuesday";
  linkLabel?: string;
};

export const REVIEW_SCORES = [
  { source: "Google",   score: 4.2, count: 725 },
  { source: "Zomato",   score: 4.1, count: 831 },
  { source: "Swiggy",   score: 4.2, count: 698 },
  { source: "Justdial", score: 4.1, count: 1486 },
] as const;

export const REVIEWS: Review[] = [
  {
    quote: "Lovely place with live music and tasty food, and staff happy to serve.",
    who: "Joy Banerjee",
    source: "Google",
    rating: 5,
    linkTo: "gazal-nights",
    linkLabel: "See Gazal Nights",
  },
  {
    quote: "We ordered drinks, pizza and Thai spring rolls — everything was on point.",
    who: "Mansi Gupta",
    source: "Google",
    rating: 5,
    linkTo: "acoustic-sundays",
    linkLabel: "Sunday music",
  },
  {
    quote: "The prices are fair for the quality and service you receive.",
    who: "Md Ashfaque Alam",
    source: "Google",
    rating: 4,
    linkTo: "open-mic-tuesday",
    linkLabel: "Open mic",
  },
  {
    quote: "Classy atmosphere and prompt service. The best part is the live music every day.",
    who: "District by Zomato",
    source: "Zomato",
    rating: 4,
    linkTo: "sufi-sundowner",
    linkLabel: "Sufi Sundowner",
  },
  {
    quote: "Delicious food, good drinks and gazal performances. Lively vibe, attentive service.",
    who: "Google reviewer",
    source: "Google",
    rating: 5,
    linkTo: "gazal-nights",
    linkLabel: "Gazal Nights",
  },
  {
    quote: "A hidden gem for music lovers — the vibe is unmatched in Noida.",
    who: "Whatshappening365",
    source: "Zomato",
    rating: 5,
    linkTo: "gazal-nights",
    linkLabel: "Live tonight",
  },
];