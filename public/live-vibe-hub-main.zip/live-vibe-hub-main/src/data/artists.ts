import a1 from "@/assets/artist-1.jpg";
import a2 from "@/assets/artist-2.jpg";
import a3 from "@/assets/artist-3.jpg";
import a4 from "@/assets/artist-4.jpg";

export type Artist = {
  slug: string;      // used in URL /artists/$slug (fallback: matching event slug)
  name: string;
  tag: string;       // one line
  genre: string;
  img: string;
  eventSlug: string; // event page to open
  city: string;
  shows: number;
};

export const ARTISTS: Artist[] = [
  { slug: "kavish-bhardwaj", name: "Kavish Bhardwaj", tag: "Gazal · Harmonium · Tabla",   genre: "Gazal",   img: a1, eventSlug: "gazal-nights",       city: "Delhi",   shows: 48 },
  { slug: "aman-qawwal",     name: "Aman Qawwal",     tag: "Sufi · Qawwali collective",    genre: "Sufi",    img: a2, eventSlug: "sufi-sundowner",      city: "Nizamuddin", shows: 36 },
  { slug: "sundown-band",    name: "The Sundown Band", tag: "Acoustic singer-songwriters", genre: "Acoustic",img: a3, eventSlug: "acoustic-sundays",    city: "Noida",   shows: 62 },
  { slug: "retro-collective",name: "Retro Collective", tag: "70s–90s Bollywood live band", genre: "Bollywood",img: a4, eventSlug: "retro-bollywood",    city: "Gurgaon", shows: 41 },
  { slug: "open-mic-crew",   name: "Open Mic Crew",   tag: "New voices every Tuesday",     genre: "Open Mic",img: a1, eventSlug: "open-mic-tuesday",    city: "NCR",     shows: 120 },
  { slug: "thursday-unplugged", name: "Thursday Unplugged", tag: "Rotating unplugged sets", genre: "Acoustic", img: a2, eventSlug: "unplugged-thursdays", city: "Noida",  shows: 28 },
];
