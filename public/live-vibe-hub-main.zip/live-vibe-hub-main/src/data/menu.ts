import food1 from "@/assets/food-1.jpg";
import food2 from "@/assets/food-2.jpg";
import food3 from "@/assets/food-3.jpg";
import foodHero from "@/assets/food-hero.jpg";

export type MenuCategory =
  | "Signatures"
  | "Small Plates"
  | "Pizza"
  | "Mains"
  | "Desserts"
  | "Coffee"
  | "Cocktails";

export type MenuItem = {
  slug: string;
  name: string;
  category: MenuCategory;
  price: string;
  priceValue?: number;
  short: string;
  description: string;
  ingredients: string[];
  allergens: string[];
  veg: boolean;
  spicy?: boolean;
  chefPick?: boolean;
  img: string;
};

export const MENU: MenuItem[] = [
  {
    slug: "grilled-fish",
    name: "Grilled Fish",
    category: "Signatures",
    price: "₹725",
    priceValue: 725,
    short: "Line-caught bassa, herbed butter, charred lemon",
    description:
      "Our most-photographed plate. Fresh line-caught bassa marinated in our secret spice blend, finished on the grill with a lemon-thyme butter and a side of seasonal greens.",
    ingredients: ["Bassa fillet", "Lemon-thyme butter", "Cracked pepper", "Grilled lemon", "Seasonal greens"],
    allergens: ["Fish", "Dairy"],
    veg: false,
    chefPick: true,
    img: food1,
  },
  {
    slug: "indian-raga-lamb-bruschetta",
    name: "Indian Raga Lamb Bruschetta",
    category: "Small Plates",
    price: "₹475",
    priceValue: 475,
    short: "Slow-cooked lamb, mint chutney, toasted focaccia",
    description:
      "A love letter to our roots — 6-hour slow-cooked lamb piled onto toasted focaccia with mint chutney and a squeeze of lime.",
    ingredients: ["Slow-cooked lamb", "House focaccia", "Mint chutney", "Pickled onion"],
    allergens: ["Gluten"],
    veg: false,
    chefPick: true,
    img: food1,
  },
  {
    slug: "rock-n-roll-nachos",
    name: "Rock N Roll Nachos",
    category: "Small Plates",
    price: "₹375",
    priceValue: 375,
    short: "Loaded nachos, three cheeses, jalapeño",
    description:
      "The stage-side staple. House-fried tortillas smothered in a three-cheese blend, salsa fresca, sour cream and jalapeños.",
    ingredients: ["Corn tortillas", "Cheddar", "Monterey jack", "Salsa fresca", "Sour cream", "Jalapeños"],
    allergens: ["Dairy", "Gluten"],
    veg: true,
    img: food3,
  },
  {
    slug: "beetroot-cheese-poppers",
    name: "Beetroot Cheese Poppers",
    category: "Small Plates",
    price: "₹325",
    priceValue: 325,
    short: "Crispy beetroot, molten cheese centre",
    description: "Beetroot-and-potato spheres wrapped around a molten cheese centre. Served with a tangy mustard aioli.",
    ingredients: ["Beetroot", "Potato", "Mozzarella", "Mustard aioli"],
    allergens: ["Dairy", "Gluten", "Egg"],
    veg: true,
    img: food3,
  },
  {
    slug: "broccoli-almond-soup",
    name: "Broccoli & Almond Soup",
    category: "Small Plates",
    price: "₹375",
    priceValue: 375,
    short: "Roasted broccoli, toasted almond, cream",
    description: "A silky bowl of roasted broccoli blitzed with toasted almonds and a swirl of cream.",
    ingredients: ["Broccoli", "Almonds", "Cream", "Garlic", "Butter"],
    allergens: ["Dairy", "Nuts"],
    veg: true,
    img: food3,
  },
  {
    slug: "wood-fired-pizza",
    name: "Wood-Fired Pizza",
    category: "Pizza",
    price: "₹520",
    priceValue: 520,
    short: "72-hour dough, San Marzano, wood fire",
    description:
      "A 72-hour cold-fermented dough, blistered in our wood oven. Choose classic Margherita, Diavola, or Quattro Formaggi.",
    ingredients: ["Sourdough base", "San Marzano tomatoes", "Buffalo mozzarella", "Basil"],
    allergens: ["Gluten", "Dairy"],
    veg: true,
    chefPick: true,
    img: foodHero,
  },
  {
    slug: "veg-tacos",
    name: "Veg Tacos",
    category: "Small Plates",
    price: "₹375",
    priceValue: 375,
    short: "Corn tortilla, charred veg, chipotle mayo",
    description: "Soft corn tortillas piled with charred seasonal veg, black bean salsa and chipotle mayo.",
    ingredients: ["Corn tortilla", "Charred veg", "Black beans", "Chipotle mayo", "Coriander"],
    allergens: ["Gluten", "Egg"],
    veg: true,
    spicy: true,
    img: food3,
  },
  {
    slug: "chicken-sharabi-tikka",
    name: "Chicken Sharabi Tikka",
    category: "Mains",
    price: "₹495",
    priceValue: 495,
    short: "Rum-glazed chicken, tandoor, smoky finish",
    description:
      "Tandoor-grilled chicken tikka finished with a smoky rum glaze. A late-night favourite on live nights.",
    ingredients: ["Chicken thigh", "Rum glaze", "Ginger-garlic marinade", "Charred onion"],
    allergens: ["Dairy"],
    veg: false,
    spicy: true,
    chefPick: true,
    img: food1,
  },
  {
    slug: "tiramisu",
    name: "Tiramisu",
    category: "Desserts",
    price: "₹395",
    priceValue: 395,
    short: "Espresso, mascarpone, cocoa",
    description: "Classic Italian tiramisu built on our own espresso and hand-whipped mascarpone.",
    ingredients: ["Ladyfingers", "Espresso", "Mascarpone", "Egg yolks", "Cocoa"],
    allergens: ["Dairy", "Egg", "Gluten"],
    veg: true,
    img: food3,
  },
  {
    slug: "lemon-tart",
    name: "Lemon Tart",
    category: "Desserts",
    price: "₹345",
    priceValue: 345,
    short: "Buttery shortcrust, torched meringue",
    description: "Silky lemon curd in a buttery shortcrust with a torched Italian meringue top.",
    ingredients: ["Butter", "Flour", "Lemon", "Egg", "Sugar"],
    allergens: ["Gluten", "Dairy", "Egg"],
    veg: true,
    img: food3,
  },
  {
    slug: "at-live-sundae",
    name: "At Live Sundae",
    category: "Desserts",
    price: "₹325",
    priceValue: 325,
    short: "Vanilla, hot fudge, brownie chunks",
    description: "House-made vanilla bean ice cream, warm fudge, brownie chunks and a maraschino cherry.",
    ingredients: ["Vanilla ice cream", "Hot fudge", "Brownie", "Cherry"],
    allergens: ["Dairy", "Gluten", "Egg"],
    veg: true,
    img: food3,
  },
  {
    slug: "cappuccino",
    name: "Cappuccino",
    category: "Coffee",
    price: "₹195",
    priceValue: 195,
    short: "Double shot, silky microfoam",
    description: "House-roasted arabica, double shot, silky microfoam. Served in a warmed cup.",
    ingredients: ["Espresso", "Steamed milk", "Microfoam"],
    allergens: ["Dairy"],
    veg: true,
    img: food2,
  },
  {
    slug: "mocha",
    name: "Mocha",
    category: "Coffee",
    price: "₹225",
    priceValue: 225,
    short: "Espresso, cocoa, steamed milk",
    description: "Rich cocoa, double espresso and steamed milk with a dust of cocoa nibs.",
    ingredients: ["Espresso", "Cocoa", "Milk", "Sugar"],
    allergens: ["Dairy"],
    veg: true,
    img: food2,
  },
  {
    slug: "sangria",
    name: "House Sangria",
    category: "Cocktails",
    price: "₹495",
    priceValue: 495,
    short: "Red wine, seasonal fruit, brandy kick",
    description: "Our house pour on live nights — red wine, seasonal fruit, orange peel and a brandy kick.",
    ingredients: ["Red wine", "Orange", "Apple", "Brandy", "Cinnamon"],
    allergens: ["Sulfites"],
    veg: true,
    img: food2,
  },
  {
    slug: "sex-on-the-beach",
    name: "Sex on the Beach",
    category: "Cocktails",
    price: "₹525",
    priceValue: 525,
    short: "Vodka, peach, cranberry, orange",
    description: "The classic. Vodka, peach schnapps, cranberry and orange over crushed ice.",
    ingredients: ["Vodka", "Peach schnapps", "Cranberry", "Orange juice"],
    allergens: [],
    veg: true,
    img: food2,
  },
  {
    slug: "masala-lemonade",
    name: "Masala Lemonade",
    category: "Cocktails",
    price: "₹275",
    priceValue: 275,
    short: "Lemon, black salt, roasted cumin",
    description: "Zero-proof house cooler with fresh lemon, black salt, roasted cumin and mint.",
    ingredients: ["Lemon", "Black salt", "Cumin", "Mint", "Soda"],
    allergens: [],
    veg: true,
    img: food2,
  },
];

export const CATEGORIES: MenuCategory[] = [
  "Signatures",
  "Small Plates",
  "Pizza",
  "Mains",
  "Desserts",
  "Coffee",
  "Cocktails",
];

export const getMenuItem = (slug: string) => MENU.find((m) => m.slug === slug);
export const getRelatedMenu = (slug: string, n = 3) => {
  const it = getMenuItem(slug);
  if (!it) return [];
  return MENU.filter((m) => m.slug !== slug && m.category === it.category).slice(0, n);
};