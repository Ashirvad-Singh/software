import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "motion/react";
import { CheckCircle2, Calendar, Users, MapPin, Phone } from "lucide-react";
import { z } from "zod";
import { fallback, zodValidator } from "@tanstack/zod-adapter";

const searchSchema = z.object({
  name: fallback(z.string(), "Guest").default("Guest"),
  date: fallback(z.string(), "").default(""),
  time: fallback(z.string(), "").default(""),
  guests: fallback(z.number(), 2).default(2),
});

export const Route = createFileRoute("/reserve/confirmed")({
  validateSearch: zodValidator(searchSchema),
  head: () => ({
    meta: [
      { title: "Reservation confirmed · AT Live Cafe" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: Confirmed,
});

function Confirmed() {
  const { name, date, time, guests } = Route.useSearch();
  const displayName = name.slice(0, 80);
  return (
    <section className="py-20">
      <div className="mx-auto max-w-2xl px-4 sm:px-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="ticket relative p-10 text-center"
        >
          <div className="absolute -top-4 left-1/2 -translate-x-1/2 h-14 w-14 rounded-full bg-accent text-accent-foreground grid place-items-center shadow-lg">
            <CheckCircle2 className="h-7 w-7" />
          </div>
          <div className="mt-4 text-xs tracking-[0.35em] text-accent">CONFIRMED</div>
          <h1 className="mt-3 font-display text-4xl sm:text-5xl uppercase leading-[0.95]">
            See you soon,<br />{displayName || "Guest"}!
          </h1>
          <p className="mt-3 font-script text-2xl text-foreground/70">a table is being held in your name</p>

          <div className="mt-8 grid grid-cols-3 gap-4 border-y-2 border-dashed border-foreground/30 py-6">
            <div>
              <Calendar className="h-4 w-4 mx-auto text-accent" />
              <div className="text-[10px] tracking-widest mt-1 text-foreground/60">DATE</div>
              <div className="font-display text-lg mt-1">{date || "—"}</div>
            </div>
            <div>
              <div className="font-display text-2xl text-accent">{time || "—"}</div>
              <div className="text-[10px] tracking-widest text-foreground/60">TIME</div>
            </div>
            <div>
              <Users className="h-4 w-4 mx-auto text-accent" />
              <div className="text-[10px] tracking-widest mt-1 text-foreground/60">GUESTS</div>
              <div className="font-display text-lg mt-1">{guests}</div>
            </div>
          </div>

          <div className="mt-6 space-y-2 text-sm text-foreground/80">
            <div className="flex items-center justify-center gap-2">
              <MapPin className="h-4 w-4 text-accent" /> HA-22, Block A, Sector 104, Noida
            </div>
            <a href="tel:+919319322100" className="flex items-center justify-center gap-2 hover:text-accent">
              <Phone className="h-4 w-4 text-accent" /> +91 93193 22100
            </a>
          </div>

          <div className="mt-8 flex flex-wrap gap-3 justify-center">
            <Link to="/menu" className="border-2 border-foreground font-display px-5 py-2.5">
              PEEK THE MENU
            </Link>
            <Link to="/events" className="bg-foreground text-background font-display px-5 py-2.5">
              WHAT'S PLAYING
            </Link>
          </div>
        </motion.div>

        <p className="mt-6 text-center text-xs text-foreground/50">
          We'll call to reconfirm groups of 6+. If plans change, ring us — no hard feelings.
        </p>
      </div>
    </section>
  );
}