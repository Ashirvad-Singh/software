import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "motion/react";
import { Flame, Leaf, Star, ArrowUpRight } from "lucide-react";
import { MENU, CATEGORIES, type MenuCategory } from "@/data/menu";

export const Route = createFileRoute("/menu")({
  head: () => ({
    meta: [
      { title: "Menu · AT Live Cafe · Sector 104, Noida" },
      { name: "description", content: "Multi-cuisine menu at AT Live Cafe — wood-fired pizza, small plates, mains, desserts, coffee and cocktails. Sector 104, Noida." },
      { property: "og:title", content: "Menu · AT Live Cafe" },
      { property: "og:description", content: "Wood-fired pizza, tikka, tacos, tiramisu, sangria — full multi-cuisine menu." },
      { property: "og:url", content: "/menu" },
    ],
    links: [{ rel: "canonical", href: "/menu" }],
  }),
  component: MenuPage,
});

type Filter = "All" | MenuCategory;

function MenuPage() {
  const [filter, setFilter] = useState<Filter>("All");
  const items = useMemo(
    () => (filter === "All" ? MENU : MENU.filter((m) => m.category === filter)),
    [filter]
  );

  return (
    <div>
      <section className="border-b-2 border-foreground/10">
        <div className="awning h-6" />
        <div className="mx-auto max-w-7xl px-4 sm:px-6 py-14 text-center">
          <div className="text-xs tracking-[0.35em] text-accent">FROM THE KITCHEN</div>
          <h1 className="mt-3 font-display text-5xl sm:text-7xl uppercase leading-[0.9]">Our Menu</h1>
          <p className="mt-4 font-script text-2xl text-foreground/70">multi-cuisine · from scratch · wood fired</p>
        </div>
      </section>

      <section className="sticky top-[57px] z-30 bg-background/95 backdrop-blur border-b border-foreground/10">
        <div className="mx-auto max-w-7xl px-3 sm:px-6 py-3 sm:py-4 flex flex-wrap gap-2 justify-center">
          {(["All", ...CATEGORIES] as Filter[]).map((c) => (
            <button
              key={c}
              onClick={() => setFilter(c)}
              className={`px-3 py-1.5 sm:px-4 sm:py-2 rounded-full text-xs sm:text-sm font-display tracking-wide transition-all ${
                filter === c
                  ? "bg-foreground text-background shadow-[3px_3px_0_0_var(--color-accent)]"
                  : "border-2 border-foreground/20 hover:border-foreground"
              }`}
            >
              {c.toUpperCase()}
            </button>
          ))}
        </div>
      </section>

      <section className="py-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((m, i) => (
            <motion.div
              key={m.slug}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: (i % 6) * 0.05 }}
              className="group paper p-4 hover:-translate-y-1 transition-transform"
            >
              <Link to="/menu/$slug" params={{ slug: m.slug }} className="block">
                <div className="relative overflow-hidden rounded-lg">
                  <img src={m.img} alt={m.name} className="h-56 w-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  <div className="absolute top-2 left-2 flex gap-1">
                    {m.chefPick && (
                      <span className="bg-accent text-accent-foreground text-[10px] tracking-widest px-2 py-0.5 font-display inline-flex items-center gap-1">
                        <Star className="h-3 w-3 fill-current" /> CHEF
                      </span>
                    )}
                    {m.veg && (
                      <span className="bg-secondary text-foreground text-[10px] tracking-widest px-2 py-0.5 font-display inline-flex items-center gap-1">
                        <Leaf className="h-3 w-3" /> VEG
                      </span>
                    )}
                    {m.spicy && (
                      <span className="bg-foreground text-background text-[10px] tracking-widest px-2 py-0.5 font-display inline-flex items-center gap-1">
                        <Flame className="h-3 w-3" />
                      </span>
                    )}
                  </div>
                </div>
                <div className="mt-4">
                  <div className="text-[10px] tracking-widest text-foreground/50 font-display">{m.category.toUpperCase()}</div>
                  <div className="mt-1 font-display text-xl leading-tight uppercase">{m.name}</div>
                </div>
                <p className="mt-2 text-sm text-foreground/70">{m.short}</p>
                <div className="mt-3 inline-flex items-center gap-1 text-xs font-display tracking-widest text-foreground/60 group-hover:text-accent">
                  SEE DISH <ArrowUpRight className="h-3 w-3" />
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </section>
    </div>
  );
}