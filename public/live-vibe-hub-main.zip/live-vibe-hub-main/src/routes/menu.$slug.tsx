import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { motion } from "motion/react";
import { ArrowLeft, Star, Leaf, Flame, ChevronRight } from "lucide-react";
import { getMenuItem, getRelatedMenu } from "@/data/menu";

export const Route = createFileRoute("/menu/$slug")({
  loader: ({ params }) => {
    const item = getMenuItem(params.slug);
    if (!item) throw notFound();
    return { item, related: getRelatedMenu(params.slug) };
  },
  head: ({ loaderData }) => ({
    meta: loaderData
      ? [
          { title: `${loaderData.item.name} · AT Live Cafe` },
          { name: "description", content: loaderData.item.short },
          { property: "og:title", content: `${loaderData.item.name} · AT Live Cafe` },
          { property: "og:description", content: loaderData.item.short },
          { property: "og:image", content: loaderData.item.img },
        ]
      : [{ title: "Dish not found" }, { name: "robots", content: "noindex" }],
    links: loaderData ? [{ rel: "canonical", href: `/menu/${loaderData.item.slug}` }] : [],
  }),
  component: MenuItemPage,
  notFoundComponent: () => (
    <div className="mx-auto max-w-3xl px-6 py-24 text-center">
      <h1 className="font-display text-5xl uppercase">Dish not found</h1>
      <Link to="/menu" className="mt-6 inline-block underline">← Back to menu</Link>
    </div>
  ),
});

function MenuItemPage() {
  const { item, related } = Route.useLoaderData();
  return (
    <div>
      <div className="mx-auto max-w-7xl px-4 sm:px-6 pt-8">
        <Link to="/menu" className="inline-flex items-center gap-1 text-sm hover:text-accent">
          <ArrowLeft className="h-4 w-4" /> Back to full menu
        </Link>
      </div>

      <section className="py-10">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 grid lg:grid-cols-2 gap-12 items-start">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
            className="relative"
          >
            <div className="aspect-square rounded-2xl overflow-hidden shadow-[var(--shadow-card)]">
              <img src={item.img} alt={item.name} className="h-full w-full object-cover" />
            </div>
            {item.chefPick && (
              <div className="absolute -top-4 -right-4 h-24 w-24 rounded-full bg-accent text-accent-foreground grid place-items-center font-display text-xs text-center rotate-[8deg] shadow-lg leading-tight">
                CHEF<br/>PICK
              </div>
            )}
          </motion.div>

          <div>
            <div className="text-xs tracking-[0.35em] text-accent">{item.category.toUpperCase()}</div>
            <h1 className="mt-3 font-display text-5xl sm:text-6xl uppercase leading-[0.95]">{item.name}</h1>
            <p className="mt-4 font-script text-2xl text-foreground/70">{item.short}</p>
            <div className="mt-4 flex flex-wrap gap-2">
              {item.chefPick && (
                <span className="bg-accent text-accent-foreground text-xs px-3 py-1 font-display inline-flex items-center gap-1">
                  <Star className="h-3 w-3 fill-current" /> CHEF PICK
                </span>
              )}
              {item.veg && (
                <span className="bg-secondary text-foreground text-xs px-3 py-1 font-display inline-flex items-center gap-1">
                  <Leaf className="h-3 w-3" /> VEG
                </span>
              )}
              {item.spicy && (
                <span className="bg-foreground text-background text-xs px-3 py-1 font-display inline-flex items-center gap-1">
                  <Flame className="h-3 w-3" /> SPICY
                </span>
              )}
            </div>

            <p className="mt-6 text-foreground/80 leading-relaxed">{item.description}</p>

            <div className="mt-8 grid sm:grid-cols-2 gap-4">
              <div className="paper p-5">
                <div className="text-xs tracking-widest font-display text-foreground/60">INGREDIENTS</div>
                <ul className="mt-2 space-y-1 text-sm">
                  {item.ingredients.map((x: string) => (
                    <li key={x} className="flex items-center gap-2">
                      <span className="h-1 w-1 rounded-full bg-accent" /> {x}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="paper p-5">
                <div className="text-xs tracking-widest font-display text-foreground/60">ALLERGENS</div>
                {item.allergens.length ? (
                  <ul className="mt-2 space-y-1 text-sm">
                    {item.allergens.map((x: string) => (
                      <li key={x} className="flex items-center gap-2">
                        <span className="h-1 w-1 rounded-full bg-foreground/60" /> {x}
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="mt-2 text-sm text-foreground/60">None declared</p>
                )}
              </div>
            </div>

            <div className="mt-8 flex gap-3">
              <Link
                to="/reserve"
                className="inline-flex items-center gap-2 bg-foreground text-background font-display px-6 py-3"
              >
                RESERVE A TABLE <ChevronRight className="h-4 w-4" />
              </Link>
              <Link
                to="/menu"
                className="inline-flex items-center gap-2 border-2 border-foreground font-display px-6 py-3"
              >
                MORE DISHES
              </Link>
            </div>
          </div>
        </div>
      </section>

      {related.length > 0 && (
        <section className="py-16 bg-card border-t border-foreground/10">
          <div className="mx-auto max-w-7xl px-4 sm:px-6">
            <h2 className="font-display text-3xl uppercase">Also in {item.category}</h2>
            <div className="mt-6 grid sm:grid-cols-3 gap-6">
              {related.map((r: typeof related[number]) => (
                <Link key={r.slug} to="/menu/$slug" params={{ slug: r.slug }} className="paper p-3 group hover:-translate-y-1 transition-transform">
                  <img src={r.img} alt={r.name} className="w-full h-40 object-cover rounded-lg" />
                  <div className="mt-3">
                    <span className="font-display uppercase">{r.name}</span>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}
    </div>
  );
}