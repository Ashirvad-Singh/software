import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "motion/react";
import { Star, ArrowUpRight } from "lucide-react";
import { REVIEWS, REVIEW_SCORES } from "@/data/reviews";

export const Route = createFileRoute("/reviews")({
  head: () => ({
    meta: [
      { title: "Reviews · AT Live Cafe · 4.2 on Google" },
      { name: "description", content: "What guests say about AT Live Cafe — live music, food, drinks and vibe. 4.2★ on Google across 725 reviews." },
      { property: "og:title", content: "Reviews · AT Live Cafe" },
      { property: "og:description", content: "4.2★ on Google, 725 reviews. Guests love the live music, food and vibe." },
      { property: "og:url", content: "/reviews" },
    ],
    links: [{ rel: "canonical", href: "/reviews" }],
  }),
  component: ReviewsPage,
});

function ReviewsPage() {
  return (
    <div>
      <section className="border-b-2 border-foreground/10">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 py-16 text-center">
          <div className="text-xs tracking-[0.35em] text-accent">SAID ABOUT US</div>
          <h1 className="mt-3 font-display text-6xl sm:text-7xl uppercase leading-[0.9]">Reviews</h1>
          <p className="mt-4 font-script text-2xl text-foreground/70">the room in the guests' words</p>

          <div className="mt-8 flex flex-wrap justify-center gap-3">
            {REVIEW_SCORES.map((s) => (
              <div key={s.source} className="inline-flex items-center gap-2 border-2 border-foreground rounded-full px-4 py-2">
                <span className="font-display text-lg">{s.score}</span>
                <Star className="h-3 w-3 fill-accent text-accent" />
                <span className="text-xs tracking-widest">{s.source.toUpperCase()} · {s.count}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-14">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {REVIEWS.map((r, i) => {
            const tilts = ["-2deg", "1deg", "-1deg", "2deg", "-3deg", "0deg"];
            return (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: (i % 3) * 0.06 }}
                style={{ transform: `rotate(${tilts[i % tilts.length]})` }}
                className="paper p-6 hover:rotate-0 transition-transform"
              >
                <div className="flex gap-0.5 mb-3">
                  {Array.from({ length: 5 }).map((_, k) => (
                    <Star key={k} className={`h-4 w-4 ${k < r.rating ? "fill-accent text-accent" : "text-foreground/25"}`} />
                  ))}
                </div>
                <p className="text-foreground/85 leading-relaxed">&ldquo;{r.quote}&rdquo;</p>
                <div className="mt-4 flex items-center justify-between">
                  <div>
                    <div className="font-script text-xl">— {r.who}</div>
                    <div className="text-[10px] tracking-widest text-foreground/50 mt-1">{r.source.toUpperCase()}</div>
                  </div>
                  {r.linkTo && r.linkLabel && (
                    <Link
                      to="/events/$eventId"
                      params={{ eventId: r.linkTo }}
                      className="text-[10px] font-display tracking-widest text-accent hover:underline inline-flex items-center gap-1"
                    >
                      {r.linkLabel} <ArrowUpRight className="h-3 w-3" />
                    </Link>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>
      </section>
    </div>
  );
}