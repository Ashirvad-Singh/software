import { createFileRoute, Link } from "@tanstack/react-router";
import { motion, AnimatePresence } from "motion/react";
import { Clock, ArrowUpRight, Search, MapPin, X, SlidersHorizontal } from "lucide-react";
import { useMemo, useState } from "react";
import { zodValidator, fallback } from "@tanstack/zod-adapter";
import { z } from "zod";
import { EVENTS } from "@/data/events";

const searchSchema = z.object({
  q: fallback(z.string(), "").default(""),
  genre: fallback(z.string(), "all").default("all"),
  when: fallback(z.string(), "all").default("all"),
  place: fallback(z.string(), "all").default("all"),
});

export const Route = createFileRoute("/events/")({
  validateSearch: zodValidator(searchSchema),
  head: () => ({
    meta: [
      { title: "Events & Live Music · AT Live Cafe · Noida" },
      { name: "description", content: "Filter by genre, date and location — gazal, sufi, Bollywood, acoustic and open mic every day at AT Live Cafe." },
      { property: "og:title", content: "Live Music at AT Live Cafe" },
      { property: "og:description", content: "Live music every day. Full multi-cuisine kitchen and bar open through the set." },
      { property: "og:url", content: "/events" },
    ],
    links: [{ rel: "canonical", href: "/events" }],
  }),
  component: EventsPage,
});

const GENRES = ["all", ...Array.from(new Set(EVENTS.map((e) => e.genre)))];
const WHENS = [
  { key: "all", label: "Any day" },
  { key: "today", label: "Today" },
  { key: "week", label: "This week" },
  { key: "weekend", label: "Weekend" },
] as const;
const PLACES = [
  { key: "all", label: "All locations" },
  { key: "indoor", label: "Indoor stage" },
  { key: "rooftop", label: "Rooftop / terrace" },
];

function dayIndex(dateStr: string): number | null {
  // "Every Fri", "Every Sat", etc.
  const map: Record<string, number> = { sun: 0, mon: 1, tue: 2, wed: 3, thu: 4, fri: 5, sat: 6 };
  const m = dateStr.toLowerCase().match(/mon|tue|wed|thu|fri|sat|sun/);
  return m ? map[m[0]] : null;
}
function matchWhen(dateStr: string, when: string): boolean {
  if (when === "all") return true;
  const day = dayIndex(dateStr);
  if (day === null) return true;
  const today = new Date().getDay();
  if (when === "today") return day === today;
  if (when === "weekend") return day === 5 || day === 6 || day === 0;
  if (when === "week") return true;
  return true;
}
function matchPlace(e: (typeof EVENTS)[number], place: string): boolean {
  if (place === "all") return true;
  const isRooftop = /rooftop|terrace|sundowner|sufi/i.test(e.artist + " " + e.about + " " + e.doorsOpen);
  return place === "rooftop" ? isRooftop : !isRooftop;
}

function EventsPage() {
  const { q, genre, when, place } = Route.useSearch();
  const navigate = Route.useNavigate();
  const [localQ, setLocalQ] = useState(q);

  const filtered = useMemo(() => {
    const query = (q || "").trim().toLowerCase();
    return EVENTS.filter((e) => {
      if (genre !== "all" && e.genre !== genre) return false;
      if (!matchWhen(e.date, when)) return false;
      if (!matchPlace(e, place)) return false;
      if (query && !(`${e.artist} ${e.genre} ${e.about} ${e.venue}`.toLowerCase().includes(query))) return false;
      return true;
    });
  }, [q, genre, when, place]);

  function setParam(k: "q" | "genre" | "when" | "place", v: string) {
    navigate({ search: (prev: Record<string, string>) => ({ ...prev, [k]: v }) });
  }
  function clearAll() {
    setLocalQ("");
    navigate({ search: () => ({ q: "", genre: "all", when: "all", place: "all" }) });
  }
  const activeCount = (q ? 1 : 0) + (genre !== "all" ? 1 : 0) + (when !== "all" ? 1 : 0) + (place !== "all" ? 1 : 0);

  return (
    <div>
      <section className="bg-foreground text-background border-b-4 border-secondary">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 py-16 text-center">
          <div className="text-xs tracking-[0.35em] text-secondary">LIVE EVERY DAY · 12–12</div>
          <h1 className="mt-3 font-display text-6xl sm:text-7xl uppercase leading-[0.9]">The Calendar</h1>
          <p className="mt-4 font-script text-2xl text-background/80">gazal · sufi · bollywood · acoustic · open mic</p>
        </div>
      </section>

      {/* Filters */}
      <section className="sticky top-16 z-30 bg-background/95 backdrop-blur border-b border-foreground/10">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 py-4">
          <div className="flex items-center gap-3 flex-wrap">
            <div className="inline-flex items-center gap-2 text-xs tracking-[0.3em] uppercase text-primary">
              <SlidersHorizontal className="h-3.5 w-3.5" /> Filter
            </div>

            <div className="relative flex-1 min-w-[220px] max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-foreground/50" />
              <input
                value={localQ}
                onChange={(e) => setLocalQ(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter") setParam("q", localQ); }}
                onBlur={() => setParam("q", localQ)}
                placeholder="Search artist, night, genre…"
                className="w-full h-10 pl-9 pr-9 rounded-full bg-secondary/40 border border-foreground/10 text-sm outline-none focus:border-primary transition"
              />
              {localQ && (
                <button
                  onClick={() => { setLocalQ(""); setParam("q", ""); }}
                  className="absolute right-2 top-1/2 -translate-y-1/2 p-1 rounded-full hover:bg-foreground/10"
                  aria-label="Clear search"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              )}
            </div>

            {activeCount > 0 && (
              <button
                onClick={clearAll}
                className="text-xs tracking-widest uppercase text-foreground/60 hover:text-primary inline-flex items-center gap-1"
              >
                <X className="h-3 w-3" /> Reset ({activeCount})
              </button>
            )}
          </div>

          {/* Chip groups */}
          <div className="mt-4 space-y-2.5">
            <ChipGroup label="Genre" value={genre} onChange={(v) => setParam("genre", v)} options={GENRES.map((g) => ({ key: g, label: g === "all" ? "All genres" : g }))} />
            <ChipGroup label="When" value={when} onChange={(v) => setParam("when", v)} options={WHENS.map((w) => ({ key: w.key, label: w.label }))} />
            <ChipGroup label="Where" value={place} onChange={(v) => setParam("place", v)} options={PLACES.map((p) => ({ key: p.key, label: p.label }))} />
          </div>
        </div>
      </section>

      <section className="py-14 sm:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="flex items-baseline justify-between mb-8">
            <div className="text-sm text-foreground/60">
              Showing <span className="text-foreground font-semibold">{filtered.length}</span> of {EVENTS.length} nights
            </div>
          </div>

          <AnimatePresence mode="popLayout">
            {filtered.length === 0 ? (
              <motion.div
                key="empty"
                initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                className="text-center py-24"
              >
                <div className="font-display text-3xl uppercase">No nights match those filters</div>
                <p className="mt-2 text-foreground/60">Try widening the genre or date.</p>
                <button onClick={clearAll} className="mt-6 inline-flex bg-primary text-primary-foreground px-6 py-3 rounded-full font-display tracking-wider">
                  Reset filters
                </button>
              </motion.div>
            ) : (
              <motion.div layout className="grid gap-10 sm:grid-cols-2 lg:grid-cols-3">
                {filtered.map((e, i) => {
                  const tilts = ["-3deg", "2deg", "-2deg", "3deg", "-1deg", "1deg"];
                  return (
                    <motion.div
                      key={e.slug}
                      layout
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      transition={{ delay: (i % 3) * 0.05 }}
                      style={{ ["--tilt" as any]: tilts[i % tilts.length] }}
                      className="polaroid"
                    >
                      <Link to="/events/$eventId" params={{ eventId: e.slug }} className="block">
                        <div className="relative overflow-hidden">
                          <img src={e.img} alt={e.artist} className="w-full h-64 object-cover" />
                          <span className="absolute top-3 left-3 bg-secondary text-foreground text-[10px] tracking-[0.25em] px-2 py-1 font-display">
                            {e.genre.toUpperCase()}
                          </span>
                        </div>
                        <div className="mt-3 px-1">
                          <div className="font-display text-lg leading-tight uppercase">{e.artist}</div>
                          <div className="mt-1 flex items-center justify-between text-xs text-foreground/70">
                            <span className="flex items-center gap-1"><Clock className="h-3 w-3" />{e.date} · {e.time}</span>
                            <span className="flex items-center gap-1"><MapPin className="h-3 w-3" />Noida</span>
                          </div>
                        </div>
                        <div className="absolute bottom-2 left-0 right-0 text-center font-script text-lg text-foreground/80">
                          {e.price.startsWith("₹0") ? "free entry" : e.price}
                        </div>
                        <ArrowUpRight className="absolute top-3 right-3 h-4 w-4 text-background bg-primary rounded-full p-0.5" />
                      </Link>
                    </motion.div>
                  );
                })}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </section>
    </div>
  );
}

function ChipGroup({
  label, value, onChange, options,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  options: { key: string; label: string }[];
}) {
  return (
    <div className="flex items-center gap-2 flex-wrap">
      <div className="text-[10px] tracking-[0.28em] uppercase text-foreground/50 w-14 shrink-0">{label}</div>
      <div className="flex items-center gap-1.5 flex-wrap">
        {options.map((o) => {
          const active = o.key === value;
          return (
            <button
              key={o.key}
              onClick={() => onChange(o.key)}
              className={`text-[11px] sm:text-xs font-display tracking-[0.14em] uppercase px-3 py-1.5 rounded-full border transition ${
                active
                  ? "bg-primary text-primary-foreground border-primary shadow-[3px_3px_0_0] shadow-foreground"
                  : "bg-background text-foreground border-foreground/20 hover:border-foreground"
              }`}
            >
              {o.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}
