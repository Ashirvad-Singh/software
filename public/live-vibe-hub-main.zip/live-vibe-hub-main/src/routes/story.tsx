import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "motion/react";
import cafeInterior from "@/assets/cafe-interior.jpg";
import food1 from "@/assets/food-1.jpg";
import food3 from "@/assets/food-3.jpg";

export const Route = createFileRoute("/story")({
  head: () => ({
    meta: [
      { title: "Our Story · AT Live Cafe · Noida" },
      { name: "description", content: "The story behind AT Live Cafe — a neighbourhood kitchen with a small stage that lights up every night. Sector 104, Noida." },
      { property: "og:title", content: "Our Story · AT Live Cafe" },
      { property: "og:description", content: "A café · music · art space in Noida since 2019." },
      { property: "og:url", content: "/story" },
    ],
    links: [{ rel: "canonical", href: "/story" }],
  }),
  component: StoryPage,
});

function StoryPage() {
  return (
    <div>
      <section className="border-b-2 border-foreground/10">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 py-14 text-center">
          <div className="text-xs tracking-[0.35em] text-accent">SINCE 2019</div>
          <h1 className="mt-3 font-display text-6xl sm:text-7xl uppercase leading-[0.9]">Our Story</h1>
          <p className="mt-4 font-script text-2xl text-foreground/70">a room, a kitchen, a small stage</p>
        </div>
      </section>

      <section className="py-14">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 grid lg:grid-cols-2 gap-12 items-center">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="paper p-8 sm:p-10">
            <p className="text-lg leading-relaxed text-foreground/85">
              AT Live began as a small kitchen with a bigger heart. Somewhere between the second
              round of coffees and the last set of the night, we realised the neighbourhood
              wanted a place that stayed open with them.
            </p>
            <p className="mt-4 text-lg leading-relaxed text-foreground/85">
              So we built one: a multi-cuisine kitchen that runs from noon till midnight, a
              proper bar, and a small stage that hosts a musician every single evening. Gazal on
              Fridays. Sufi on Saturdays. Acoustic Sundays. Open Mic Tuesdays. Bollywood
              Wednesdays.
            </p>
            <p className="mt-4 text-lg leading-relaxed text-foreground/85">
              The events are a love letter to our guests. But the cafe — the room, the plate,
              the drink in your hand — that's always the star.
            </p>
            <div className="mt-6 font-script text-3xl text-accent">— Team AT Live</div>
          </motion.div>

          <div className="grid grid-cols-2 gap-4">
            <motion.img initial={{ opacity: 0, rotate: -6, y: 20 }} whileInView={{ opacity: 1, rotate: -3, y: 0 }} viewport={{ once: true }} src={cafeInterior} alt="Interior" className="w-full h-56 object-cover rounded-lg shadow-lg" />
            <motion.img initial={{ opacity: 0, rotate: 6, y: 20 }} whileInView={{ opacity: 1, rotate: 3, y: 0 }} viewport={{ once: true }} src={food1} alt="Food" className="w-full h-56 object-cover rounded-lg shadow-lg mt-8" />
            <motion.img initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} src={food3} alt="Plate" className="w-full h-56 object-cover rounded-lg shadow-lg col-span-2" />
          </div>
        </div>
      </section>

      <section className="bg-foreground text-background py-16">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 text-center">
          <h2 className="font-display text-4xl sm:text-5xl uppercase">Come as you are.</h2>
          <p className="mt-4 text-background/80">Grab a table for lunch. Bring the crew for the late set. Just pop in for a coffee.</p>
          <div className="mt-8 flex justify-center gap-3 flex-wrap">
            <Link to="/menu" className="bg-secondary text-foreground font-display px-6 py-3">SEE THE MENU</Link>
            <Link to="/reserve" className="border-2 border-background font-display px-6 py-3">RESERVE A TABLE</Link>
          </div>
        </div>
      </section>
    </div>
  );
}