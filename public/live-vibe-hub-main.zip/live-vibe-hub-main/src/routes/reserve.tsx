import { useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { motion } from "motion/react";
import { Calendar, Clock, Users, User, Mail, Phone, ArrowRight } from "lucide-react";

export const Route = createFileRoute("/reserve")({
  head: () => ({
    meta: [
      { title: "Reserve a Table · AT Live Cafe" },
      { name: "description", content: "Reserve your table at AT Live Cafe, Sector 104 Noida. Live music every night, full multi-cuisine menu and bar." },
      { property: "og:title", content: "Reserve · AT Live Cafe" },
      { property: "og:description", content: "Book a table for lunch, dinner or a live night." },
      { property: "og:url", content: "/reserve" },
    ],
    links: [{ rel: "canonical", href: "/reserve" }],
  }),
  component: ReservePage,
});

const TIMES = ["12:30", "13:30", "15:00", "18:30", "19:30", "20:30", "21:30", "22:30"];

function ReservePage() {
  const navigate = useNavigate();
  const today = new Date().toISOString().slice(0, 10);
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    date: today,
    time: "20:30",
    guests: 2,
    occasion: "",
    notes: "",
  });
  const [submitting, setSubmitting] = useState(false);

  const set = <K extends keyof typeof form>(k: K, v: (typeof form)[K]) =>
    setForm((f) => ({ ...f, [k]: v }));

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.phone) return;
    setSubmitting(true);
    setTimeout(() => {
      navigate({
        to: "/reserve/confirmed",
        search: {
          name: form.name,
          date: form.date,
          time: form.time,
          guests: form.guests,
        },
      });
    }, 600);
  };

  return (
    <div>
      <section className="border-b-2 border-foreground/10">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 py-14 text-center">
          <div className="text-xs tracking-[0.35em] text-accent">RESERVATIONS</div>
          <h1 className="mt-3 font-display text-5xl sm:text-7xl uppercase leading-[0.9]">Save a Table</h1>
          <p className="mt-4 font-script text-2xl text-foreground/70">we'll save you a story</p>
        </div>
      </section>

      <section className="py-14">
        <div className="mx-auto max-w-4xl px-4 sm:px-6">
          <motion.form
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            onSubmit={onSubmit}
            className="paper p-6 sm:p-10 grid gap-5"
          >
            <div className="grid sm:grid-cols-2 gap-5">
              <Field icon={<User className="h-4 w-4" />} label="Name">
                <input
                  required
                  value={form.name}
                  onChange={(e) => set("name", e.target.value)}
                  className="w-full bg-transparent outline-none py-2 text-lg"
                  placeholder="Your name"
                  maxLength={80}
                />
              </Field>
              <Field icon={<Phone className="h-4 w-4" />} label="Phone">
                <input
                  required
                  type="tel"
                  value={form.phone}
                  onChange={(e) => set("phone", e.target.value.replace(/[^\d+\s-]/g, "").slice(0, 20))}
                  className="w-full bg-transparent outline-none py-2 text-lg"
                  placeholder="+91 ..."
                />
              </Field>
            </div>

            <Field icon={<Mail className="h-4 w-4" />} label="Email (optional)">
              <input
                type="email"
                value={form.email}
                onChange={(e) => set("email", e.target.value.slice(0, 120))}
                className="w-full bg-transparent outline-none py-2 text-lg"
                placeholder="you@example.com"
              />
            </Field>

            <div className="grid sm:grid-cols-3 gap-5">
              <Field icon={<Calendar className="h-4 w-4" />} label="Date">
                <input
                  required
                  type="date"
                  min={today}
                  value={form.date}
                  onChange={(e) => set("date", e.target.value)}
                  className="w-full bg-transparent outline-none py-2 text-lg"
                />
              </Field>
              <Field icon={<Clock className="h-4 w-4" />} label="Time">
                <select
                  value={form.time}
                  onChange={(e) => set("time", e.target.value)}
                  className="w-full bg-transparent outline-none py-2 text-lg"
                >
                  {TIMES.map((t) => (
                    <option key={t} value={t}>{t}</option>
                  ))}
                </select>
              </Field>
              <Field icon={<Users className="h-4 w-4" />} label="Guests">
                <select
                  value={form.guests}
                  onChange={(e) => set("guests", Number(e.target.value))}
                  className="w-full bg-transparent outline-none py-2 text-lg"
                >
                  {Array.from({ length: 12 }, (_, i) => i + 1).map((n) => (
                    <option key={n} value={n}>{n} {n === 1 ? "guest" : "guests"}</option>
                  ))}
                </select>
              </Field>
            </div>

            <Field label="Occasion (optional)">
              <select
                value={form.occasion}
                onChange={(e) => set("occasion", e.target.value)}
                className="w-full bg-transparent outline-none py-2 text-lg"
              >
                <option value="">—</option>
                <option value="birthday">Birthday</option>
                <option value="anniversary">Anniversary</option>
                <option value="date">Date night</option>
                <option value="live">Live music night</option>
                <option value="business">Business</option>
              </select>
            </Field>

            <Field label="Notes (optional)">
              <textarea
                value={form.notes}
                onChange={(e) => set("notes", e.target.value.slice(0, 500))}
                className="w-full bg-transparent outline-none py-2 text-lg resize-none"
                rows={3}
                placeholder="Allergies, seating preference, surprise cake..."
              />
            </Field>

            <button
              type="submit"
              disabled={submitting}
              className="mt-4 inline-flex items-center justify-center gap-2 bg-foreground text-background font-display text-xl tracking-wide px-8 py-4 shadow-[6px_6px_0_0_var(--color-accent)] hover:translate-x-[2px] hover:translate-y-[2px] hover:shadow-[3px_3px_0_0_var(--color-accent)] transition-all disabled:opacity-70"
            >
              {submitting ? "SAVING..." : (<>CONFIRM RESERVATION <ArrowRight className="h-5 w-5" /></>)}
            </button>

            <p className="text-xs text-foreground/60 text-center">
              Or call us directly:{" "}
              <a href="tel:+919319322100" className="underline">+91 93193 22100</a>
            </p>
          </motion.form>

          <div className="mt-8 text-center">
            <Link to="/events" className="underline text-sm">See what's playing tonight →</Link>
          </div>
        </div>
      </section>
    </div>
  );
}

function Field({ icon, label, children }: { icon?: React.ReactNode; label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="text-[11px] tracking-widest font-display text-foreground/60 inline-flex items-center gap-2">
        {icon} {label.toUpperCase()}
      </span>
      <div className="mt-1 border-b-2 border-foreground/20 focus-within:border-accent transition-colors">
        {children}
      </div>
    </label>
  );
}