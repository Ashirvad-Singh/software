import { createFileRoute, Link } from "@tanstack/react-router";
import { MapPin, Phone, Clock, Instagram, Mail } from "lucide-react";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact · AT Live Cafe · Sector 104, Noida" },
      { name: "description", content: "Visit AT Live Cafe at HA-22, Block A, Sector 104, Hajipur, Noida. Open all days 12pm–12am. Call +91 93193 22100." },
      { property: "og:title", content: "Contact · AT Live Cafe" },
      { property: "og:description", content: "HA-22, Sector 104, Noida · +91 93193 22100 · open 12pm to 12am." },
      { property: "og:url", content: "/contact" },
    ],
    links: [{ rel: "canonical", href: "/contact" }],
  }),
  component: ContactPage,
});

function ContactPage() {
  return (
    <div>
      <section className="border-b-2 border-foreground/10">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 py-14 text-center">
          <div className="text-xs tracking-[0.35em] text-accent">FIND US</div>
          <h1 className="mt-3 font-display text-6xl sm:text-7xl uppercase leading-[0.9]">Contact</h1>
          <p className="mt-4 font-script text-2xl text-foreground/70">walk in · call · dm</p>
        </div>
      </section>

      <section className="py-14">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 grid lg:grid-cols-2 gap-10">
          <div className="paper p-8 space-y-6">
            <InfoRow icon={<MapPin className="h-5 w-5 text-accent" />} label="ADDRESS">
              HA-22, Block A, Sector 104,<br />Hajipur, Noida 201304
            </InfoRow>
            <InfoRow icon={<Phone className="h-5 w-5 text-accent" />} label="PHONE">
              <a href="tel:+919319322100" className="hover:text-accent">+91 93193 22100</a>
            </InfoRow>
            <InfoRow icon={<Mail className="h-5 w-5 text-accent" />} label="EMAIL">
              <a href="mailto:hello@atlivecafe.in" className="hover:text-accent">hello@atlivecafe.in</a>
            </InfoRow>
            <InfoRow icon={<Clock className="h-5 w-5 text-accent" />} label="HOURS">
              All days · 12 pm – 12 am<br />
              <span className="font-script text-lg text-accent">live music, every day</span>
            </InfoRow>
            <InfoRow icon={<Instagram className="h-5 w-5 text-accent" />} label="INSTAGRAM">
              <a href="https://instagram.com/atlivenoida" target="_blank" rel="noreferrer" className="hover:text-accent">@atlivenoida · 35k fam</a>
            </InfoRow>

            <div className="pt-4 flex flex-wrap gap-3">
              <Link to="/reserve" className="bg-foreground text-background font-display px-6 py-3">RESERVE A TABLE</Link>
              <a href="tel:+919319322100" className="border-2 border-foreground font-display px-6 py-3">CALL NOW</a>
            </div>
          </div>

          <div className="rounded-2xl overflow-hidden shadow-[var(--shadow-card)] min-h-[420px]">
            <iframe
              title="AT Live Cafe location"
              src="https://www.google.com/maps?q=AT+Live+Cafe+HA-22+Sector+104+Hajipur+Noida&output=embed"
              className="w-full h-full min-h-[420px] border-0"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </div>
      </section>
    </div>
  );
}

function InfoRow({ icon, label, children }: { icon: React.ReactNode; label: string; children: React.ReactNode }) {
  return (
    <div className="flex gap-4">
      <div className="mt-1">{icon}</div>
      <div>
        <div className="text-[10px] tracking-[0.3em] text-foreground/50 font-display">{label}</div>
        <div className="mt-1 text-lg">{children}</div>
      </div>
    </div>
  );
}