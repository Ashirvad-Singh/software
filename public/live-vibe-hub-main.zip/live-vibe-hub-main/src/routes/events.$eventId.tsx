import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { motion } from "motion/react";
import {
  ArrowUpRight, Calendar as CalendarIcon, Clock, MapPin, Music,
  Ticket, Share2, Heart, ArrowLeft, Utensils, ParkingCircle, Accessibility,
  ChevronRight,
} from "lucide-react";
import { EVENTS, getEvent, getRelated } from "@/data/events";
import { useState } from "react";
import { BookingDialog, type BookingIntent } from "@/components/booking/BookingDialog";

export const Route = createFileRoute("/events/$eventId")({
  loader: ({ params }) => {
    const event = getEvent(params.eventId);
    if (!event) throw notFound();
    return { event, related: getRelated(params.eventId, 3) };
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return { meta: [{ title: "Event not found · AT Live Cafe" }, { name: "robots", content: "noindex" }] };
    }
    const { event } = loaderData;
    const title = `${event.artist} · ${event.date} — AT Live Cafe`;
    const desc = `${event.artist} live at ${event.venue}. ${event.date} · ${event.time}. Book a table, dinner + show.`;
    return {
      meta: [
        { title },
        { name: "description", content: desc },
        { property: "og:title", content: title },
        { property: "og:description", content: desc },
        { property: "og:type", content: "website" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  component: EventDetails,
  notFoundComponent: EventNotFound,
  errorComponent: ({ reset }) => (
    <div className="min-h-screen grid place-items-center p-8">
      <div className="text-center">
        <h1 className="text-3xl font-semibold">Something went wrong</h1>
        <button onClick={() => reset()} className="mt-4 px-5 py-2 rounded-full bg-foreground text-background text-sm">Try again</button>
      </div>
    </div>
  ),
});

function EventNotFound() {
  return (
    <div className="min-h-screen grid place-items-center p-8">
      <div className="text-center">
        <div className="text-xs uppercase tracking-[0.3em] text-primary">404</div>
        <h1 className="mt-3 text-4xl font-semibold">Event not found</h1>
        <p className="mt-3 text-foreground/60">This show may have wrapped up. Check what's on next.</p>
        <Link to="/" className="mt-6 inline-flex items-center gap-2 px-5 py-3 rounded-full bg-foreground text-background text-sm font-medium">
          Back to cafe <ArrowUpRight className="h-4 w-4" />
        </Link>
      </div>
    </div>
  );
}

function EventDetails() {
  const { event, related } = Route.useLoaderData();
  const [active, setActive] = useState(0);
  const [bookingOpen, setBookingOpen] = useState(false);
  const [bookingIntent, setBookingIntent] = useState<BookingIntent | null>(null);
  const gallery = event.gallery.length ? event.gallery : [event.img];

  const priceNumber = Number(String(event.price).replace(/[^\d]/g, "")) || 499;

  function openBooking(kind: "event" | "table") {
    setBookingIntent({
      kind,
      title: kind === "event" ? `${event.artist} · ${event.date}` : `Table · ${event.venue}`,
      subtitle: kind === "event" ? `${event.time} · ${event.venue}` : "Dinner reservation",
      pricePerSeat: kind === "event" ? priceNumber : 250,
      defaultDate: new Date(),
      eventSlug: event.slug,
    });
    setBookingOpen(true);
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Top bar */}
      <div className="sticky top-0 z-40 backdrop-blur bg-background/70 border-b border-foreground/5">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 py-4 flex items-center justify-between">
          <Link to="/" className="inline-flex items-center gap-2 text-sm hover:opacity-80">
            <ArrowLeft className="h-4 w-4" /> Back to cafe
          </Link>
          <div className="flex items-center gap-2">
            <button className="grid h-9 w-9 place-items-center rounded-full glass" aria-label="Save"><Heart className="h-4 w-4" /></button>
            <button className="grid h-9 w-9 place-items-center rounded-full glass" aria-label="Share"><Share2 className="h-4 w-4" /></button>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 sm:px-6 pt-8 pb-24">
        {/* Breadcrumb */}
        <nav className="text-xs text-foreground/50 flex items-center gap-1.5">
          <Link to="/" className="hover:text-foreground">AT Live Cafe</Link>
          <ChevronRight className="h-3 w-3" />
          <span>Events</span>
          <ChevronRight className="h-3 w-3" />
          <span className="text-foreground/80">{event.artist}</span>
        </nav>

        {/* Title */}
        <div className="mt-6 flex flex-wrap items-end justify-between gap-6">
          <div>
            <div className="text-xs uppercase tracking-[0.25em] text-primary">{event.genre} · Live at the cafe</div>
            <h1 className="mt-3 text-5xl sm:text-7xl font-semibold tracking-tight leading-[0.95]" style={{ fontFamily: "'Space Grotesk', Inter, sans-serif" }}>
              {event.artist}
            </h1>
            <div className="mt-4 flex flex-wrap gap-4 text-sm text-foreground/70">
              <span className="inline-flex items-center gap-1.5"><CalendarIcon className="h-4 w-4" /> {event.date}</span>
              <span className="inline-flex items-center gap-1.5"><Clock className="h-4 w-4" /> {event.time}</span>
              <span className="inline-flex items-center gap-1.5"><MapPin className="h-4 w-4" /> {event.venue}</span>
              <span className="inline-flex items-center gap-1.5"><Ticket className="h-4 w-4" /> {event.seats} seats left</span>
            </div>
          </div>
        </div>

        {/* Gallery */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mt-10 grid gap-3 lg:grid-cols-4"
        >
          <div className="lg:col-span-3 relative aspect-[16/10] rounded-[2rem] overflow-hidden bg-card shadow-[var(--shadow-card)]">
            <img src={gallery[active]} alt={event.artist} className="h-full w-full object-cover" width={1600} height={1000} />
            <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent" />
            <div className="absolute bottom-5 left-5 flex gap-2">
              <span className="inline-flex items-center gap-1 text-[10px] uppercase tracking-widest bg-white/90 text-black px-2.5 py-1 rounded-full">
                {event.genre}
              </span>
              <span className="inline-flex items-center gap-1 text-[10px] uppercase tracking-widest bg-primary text-white px-2.5 py-1 rounded-full">
                <Music className="h-3 w-3" /> Live
              </span>
            </div>
          </div>
          <div className="grid grid-cols-4 lg:grid-cols-1 gap-3">
            {gallery.map((g: string, i: number) => (
              <button
                key={i}
                onClick={() => setActive(i)}
                className={`relative aspect-square lg:aspect-[4/3] rounded-2xl overflow-hidden transition ${
                  active === i ? "ring-2 ring-primary" : "opacity-80 hover:opacity-100"
                }`}
              >
                <img src={g} alt="" className="h-full w-full object-cover" loading="lazy" />
              </button>
            ))}
          </div>
        </motion.div>

        {/* Main grid */}
        <div className="mt-14 grid gap-10 lg:grid-cols-3">
          <div className="lg:col-span-2 space-y-12">
            {/* About */}
            <section>
              <div className="text-xs uppercase tracking-[0.25em] text-primary">About the night</div>
              <h2 className="mt-2 text-3xl font-semibold tracking-tight" style={{ fontFamily: "'Space Grotesk', Inter, sans-serif" }}>
                Dinner &amp; a show.
              </h2>
              <p className="mt-4 text-foreground/70 leading-relaxed">{event.about}</p>
              <div className="mt-6 grid gap-4 sm:grid-cols-3">
                {[
                  { icon: Utensils, k: "Full menu", v: "Kitchen open through the set" },
                  { icon: ParkingCircle, k: "Parking", v: "Valet available on site" },
                  { icon: Accessibility, k: "Accessible", v: "Step-free entry & seating" },
                ].map((f) => (
                  <div key={f.k} className="rounded-2xl bg-card p-4 shadow-[var(--shadow-card)]">
                    <f.icon className="h-5 w-5 text-primary" />
                    <div className="mt-2 text-sm font-semibold">{f.k}</div>
                    <div className="text-xs text-foreground/60 mt-0.5">{f.v}</div>
                  </div>
                ))}
              </div>
            </section>

            {/* Venue */}
            <section>
              <div className="text-xs uppercase tracking-[0.25em] text-primary">Venue</div>
              <h2 className="mt-2 text-3xl font-semibold tracking-tight" style={{ fontFamily: "'Space Grotesk', Inter, sans-serif" }}>
                {event.venue}
              </h2>
              <p className="mt-2 text-foreground/70 text-sm inline-flex items-center gap-2">
                <MapPin className="h-4 w-4" /> {event.address}
              </p>
              <p className="mt-2 text-foreground/60 text-sm">{event.doorsOpen}</p>

              <div className="mt-5 rounded-[1.75rem] overflow-hidden bg-card shadow-[var(--shadow-card)]">
                <iframe
                  title={`Map to ${event.venue}`}
                  src={`https://www.google.com/maps?q=${encodeURIComponent(event.mapQuery)}&output=embed`}
                  className="w-full h-[380px] border-0"
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
                <div className="p-4 flex flex-wrap items-center justify-between gap-3">
                  <div className="text-sm text-foreground/70">Nearest metro · 6 min walk</div>
                  <a
                    href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(event.mapQuery)}`}
                    target="_blank" rel="noreferrer"
                    className="inline-flex items-center gap-1 text-sm px-4 py-2 rounded-full bg-foreground text-background hover:gap-2 transition-all"
                  >
                    Get directions <ArrowUpRight className="h-4 w-4" />
                  </a>
                </div>
              </div>
            </section>
          </div>

          {/* Booking card */}
          <aside className="lg:col-span-1">
            <div className="sticky top-24 rounded-[1.75rem] bg-card p-6 shadow-[var(--shadow-card)] border border-foreground/5">
              <div className="text-[11px] uppercase tracking-widest text-foreground/50">Tickets from</div>
              <div className="mt-1 flex items-baseline gap-2">
                <div className="text-4xl font-semibold" style={{ fontFamily: "'Space Grotesk', Inter, sans-serif" }}>{event.price}</div>
                <div className="text-xs text-foreground/60">/ seat</div>
              </div>
              <div className="mt-4 text-xs text-foreground/60 flex items-center gap-1"><Ticket className="h-3.5 w-3.5" /> {event.seats} seats left</div>

              <div className="mt-5 space-y-2 text-sm">
                <div className="flex justify-between"><span className="text-foreground/60">Date</span><span>{event.date}</span></div>
                <div className="flex justify-between"><span className="text-foreground/60">Show time</span><span>{event.time}</span></div>
                <div className="flex justify-between"><span className="text-foreground/60">Doors</span><span>{event.doorsOpen.split("·")[0].trim()}</span></div>
              </div>

              <button
                onClick={() => openBooking("event")}
                className="mt-6 w-full py-3.5 rounded-full bg-primary text-primary-foreground text-sm font-semibold hover:opacity-90 transition"
              >
                Book seats
              </button>
              <button
                onClick={() => openBooking("table")}
                className="mt-2 w-full py-3.5 rounded-full glass text-sm font-medium"
              >
                Reserve a table only
              </button>
              <p className="mt-4 text-[11px] text-foreground/50 text-center">Free cancellation up to 24h before doors.</p>
            </div>
          </aside>
        </div>

        {/* Related */}
        <section className="mt-24">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <div className="text-xs uppercase tracking-[0.25em] text-primary">More nights at the cafe</div>
              <h2 className="mt-2 text-3xl sm:text-4xl font-semibold tracking-tight" style={{ fontFamily: "'Space Grotesk', Inter, sans-serif" }}>
                You might also love.
              </h2>
            </div>
            <Link to="/" className="inline-flex items-center gap-1 text-sm hover:gap-2 transition-all">
              All events <ChevronRight className="h-4 w-4" />
            </Link>
          </div>

          <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {related.map((r: typeof related[number]) => (
              <Link
                key={r.slug}
                to="/events/$eventId"
                params={{ eventId: r.slug }}
                className="group rounded-[1.75rem] overflow-hidden bg-card shadow-[var(--shadow-card)] block"
              >
                <div className="relative aspect-[4/3] overflow-hidden">
                  <img src={r.img} alt={r.artist} className="h-full w-full object-cover transition duration-700 group-hover:scale-105" loading="lazy" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                  <span className="absolute top-3 left-3 inline-flex text-[10px] uppercase tracking-widest bg-white/90 text-black px-2 py-1 rounded-full">{r.genre}</span>
                </div>
                <div className="p-4">
                  <div className="font-semibold" style={{ fontFamily: "'Space Grotesk', Inter, sans-serif" }}>{r.artist}</div>
                  <div className="mt-1 text-xs text-foreground/60 flex items-center gap-2">
                    <CalendarIcon className="h-3 w-3" /> {r.date} · {r.time}
                  </div>
                  <div className="mt-1 text-xs text-foreground/60 flex items-center gap-1">
                    <MapPin className="h-3 w-3" /> {r.venue}
                  </div>
                  <div className="mt-3 flex items-center justify-between">
                    <span className="text-sm font-semibold">{r.price}</span>
                    <span className="inline-flex items-center gap-1 text-xs text-foreground/70 group-hover:gap-2 transition-all">
                      Details <ArrowUpRight className="h-3 w-3" />
                    </span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </section>
      </div>

      {bookingIntent && (
        <BookingDialog open={bookingOpen} onOpenChange={setBookingOpen} intent={bookingIntent} />
      )}
    </div>
  );
}

// Suppress unused-import warnings for EVENTS in strict builds if tree-shaken.
void EVENTS;